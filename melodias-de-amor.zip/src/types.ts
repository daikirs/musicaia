/**
 * Type declarations for Melodias de Amor lead checkout funnel.
 */

export interface LeadQuizData {
  // Step 1: O Básico
  targetName: string;
  relationship: string; // "Namorado(a)", "Marido/Esposa", "Amante", "Amigo(a)", "Mãe/Pai", "Filho(a)", "Outro"
  customRelationship?: string;

  // Step 2: Detalhes Especiais
  qualities: string;
  unforgettableMoments: string;
  specialMessage?: string;
  occasion: string; // "Aniversário", "Dia dos Namorados", "Aniversário de Casamento", "Pedido de Namoro", "Sem Motivo Especial", "Outra"
  customOccasion?: string;

  // Step 3: Gênero e Voz
  genre: string; // "Sertanejo Romântico", "Pop Acústico (Estilo MPB)", "Pagode Romântico", "Indie Folk", "R&B / Soul", "Bossa Nova"
  customGenre?: string;
  voiceType: string; // "Feminina", "Masculina", "Dueto Romântico (+ R$ 15,00)"

  // Step 4: Plano
  planId: "basico" | "flash";
  couponCode?: string;

  // Step 5: Contato & Pagamento
  clientName: string;
  clientEmail: string;
  clientWhatsapp: string;

  // Metadata
  id?: string;
  createdAt?: Date | string;
  status?: "pending" | "paid" | "completed";
}

export interface Testimonial {
  name: string;
  relationship: string;
  text: string;
  avatarUrl?: string;
  rating: number;
}

export interface FAQItem {
  question: string;
  answer: string;
}
