/**
 * Customized poetic lyrics generator for Melodias de Amor.
 * Resolves lead responses into elegant song structures in Portuguese.
 */

export interface LyricsResult {
  title: string;
  intro: string;
  verso1: string;
  verso2: string;
  refrao: string;
  ponte: string;
  outro: string;
}

export function generateCustomLyrics(
  targetName: string,
  relationship: string,
  qualities: string,
  unforgettableMoments: string,
  occasion: string,
  genreName: string
): LyricsResult {
  const name = targetName || "Você";
  const cleanQualities = qualities ? qualities.trim() : "sua doçura e sua paz";
  const cleanMoments = unforgettableMoments ? unforgettableMoments.trim() : "nossos instantes divididos e nossos sorrisos";

  // Customize based on relationship and occasion
  const title = `Melodia para ${name}`;
  
  return {
    title,
    intro: `(Instrumentação suave de ${genreName} se inicia, trazendo aconchego...)`,
    verso1: `O compasso do meu peito se acerta com o teu falar,\nNo rastro dos seus passos, aprendi a caminhar.\nOlho para você, ${name}, e vejo o quanto a vida mudou,\nE o laço forte de ${relationship.toLowerCase()} que o destino desenhou.\nPor tudo o que define você — ${cleanQualities} —\nEncontrei o meu abrigo e a minha melhor versão.`,
    
    verso2: `Dizem que o tempo corre, mas na verdade ele para\nQuando a sua risada doce neste silêncio dispara.\nLembro-me de quando vivemos algo tão especial e sem fim:\n${cleanMoments}.\nCada pedacinho desse dia ficou gravado bem fundo em mim,\nComo uma canção perfeita tocando no rádio sem fim.`,
    
    refrao: `Para você, meu amor, fiz cantar esta canção,\nPara expressar em acordes o pulsar do coração.\nSeja no ${occasion.toLowerCase()} ou em qualquer outro luar,\nMinha maior melodia é ver o seu olhar brilhar!\n${name}, você é o meu refrão mais bonito,\nUm porto de carinho neste peito infinito.`,
    
    ponte: `E mesmo que as palavras faltem para traduzir a emoção,\nOs violões e acordes levam minha voz em sua direção.\nQue esta melodia abrace sua alma e te faça sorrir,\nLembrando que estarei com você em todo passo que se seguir.`,
    
    outro: `(A melodia de ${genreName} vai se despedindo suavemente...)\nEstarei sempre aqui, embalando nosso amor.\nTermina em um fade-out suave e apaixonado.`
  };
}
