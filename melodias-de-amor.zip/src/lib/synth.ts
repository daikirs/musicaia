/**
 * Soft romantic synthesizer engine using Web Audio API to play gentle theme previews.
 */

let audioCtx: AudioContext | null = null;

function getAudioContext() {
  if (!audioCtx) {
    // @ts-ignore
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

// Keep track of any active synth timers/intervals to prevent overlaps
let activeInterval: any = null;
let activeNodes: AudioNode[] = [];

/**
 * Stop any currently playing audio nodes
 */
export function stopAllPreviews() {
  if (activeInterval) {
    clearInterval(activeInterval);
    activeInterval = null;
  }
  activeNodes.forEach(node => {
    try {
      // @ts-ignore
      node.stop();
    } catch {
      // Ignore
    }
  });
  activeNodes = [];
}

/**
 * Play a beautiful, low-pass filtered chord progression depending on style.
 */
export function playStylePreview(style: string) {
  stopAllPreviews();
  
  const ctx = getAudioContext();
  if (!ctx) return;

  // Let's design some gentle chord notes (frequencies) for each style.
  // We use romantic pentatonic progressions (C Major, G Major, A Minor, F Major)
  // or elegant jazz chords.
  const chordSet: Record<string, number[][]> = {
    sertanejo: [
      [261.63, 329.63, 392.00, 523.25], // C Major
      [293.66, 369.99, 440.00, 587.33], // D Major
      [329.63, 392.00, 493.88, 659.25], // E Minor
      [349.23, 440.00, 523.25, 698.46]  // F Major
    ],
    acoustics: [
      [293.66, 349.23, 440.00, 587.33], // D Minor
      [349.23, 440.00, 523.25, 698.46], // F Major
      [261.63, 329.63, 392.00, 523.25], // C Major
      [196.00, 246.94, 293.66, 392.00]  // G Major
    ],
    pagode: [
      [261.63, 329.63, 392.00, 493.88], // C Major 7
      [220.00, 261.63, 329.63, 392.00], // A Minor 7
      [293.66, 349.23, 440.00, 523.25], // D Minor 7
      [196.00, 246.94, 293.66, 349.23]  // G Dominant 7
    ],
    folk: [
      [196.00, 293.66, 392.00, 493.88], // G Major
      [220.00, 329.63, 440.00, 523.25], // A Minor
      [349.23, 440.00, 523.25, 698.46], // F Major
      [261.63, 329.63, 392.00, 523.25]  // C Major
    ],
    jazz: [
      [261.63, 311.13, 392.00, 466.16], // C Minor 7
      [311.13, 392.00, 466.16, 587.33], // Eb Major 7
      [293.66, 349.23, 440.00, 523.25], // D Minor 7
      [196.00, 246.94, 293.66, 349.23]  // G 7
    ]
  };

  const selectedChords = chordSet[style] || chordSet.acoustics;
  let chordIndex = 0;

  // Let's create a soft main output filter to make it sound "dreamy" and analog
  const mainFilter = ctx.createBiquadFilter();
  mainFilter.type = "lowpass";
  mainFilter.frequency.setValueAtTime(650, ctx.currentTime);
  mainFilter.Q.setValueAtTime(1.5, ctx.currentTime);

  const delayNode = ctx.createDelay();
  delayNode.delayTime.value = 0.35;
  const feedbackNode = ctx.createGain();
  feedbackNode.gain.value = 0.45;

  const mainGain = ctx.createGain();
  mainGain.gain.setValueAtTime(0.18, ctx.currentTime); // keep nice quiet volume

  // Connect synthesizer delay chain
  mainFilter.connect(mainGain);
  mainFilter.connect(delayNode);
  delayNode.connect(feedbackNode);
  feedbackNode.connect(delayNode);
  feedbackNode.connect(mainGain);
  mainGain.connect(ctx.destination);

  activeNodes.push(mainFilter, mainGain, delayNode, feedbackNode);

  // Function to trigger an individual note gently
  const playNote = (pitch: number, time: number, duration: number, voiceType: OscillatorType = "triangle") => {
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = voiceType;
    osc.frequency.setValueAtTime(pitch, time);

    // Human-style acoustic attack and release
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(0.25, time + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.001, time + duration);

    osc.connect(gain);
    gain.connect(mainFilter);

    osc.start(time);
    osc.stop(time + duration);

    activeNodes.push(osc, gain);
  };

  const playChordTrigger = () => {
    const chord = selectedChords[chordIndex];
    const now = ctx.currentTime;

    // Arpeggiate notes for an organic, human-played guitar/piano feeling
    chord.forEach((note, index) => {
      const delayTime = index * 0.12;
      const duration = 2.4 - (index * 0.1);
      // Main harmony chord
      playNote(note, now + delayTime, duration, "triangle");

      // Add a sparkling beautiful high bell harmonic
      if (index === 3) {
        playNote(note * 2, now + delayTime + 0.4, 0.8, "sine");
      }
    });

    chordIndex = (chordIndex + 1) % selectedChords.length;
  };

  // Play first immediately
  playChordTrigger();

  // Schedule next chords every 2.8 seconds
  activeInterval = setInterval(() => {
    playChordTrigger();
  }, 2800);
}
