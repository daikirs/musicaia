import { initializeApp, getApp, getApps } from "firebase/app";
import { getAuth, signInAnonymously, User } from "firebase/auth";
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDocFromServer, 
  serverTimestamp,
  getFirestore as getFirestoreSDK
} from "firebase/firestore";
// @ts-ignore
import firebaseConfig from "../../firebase-applet-config.json";
import { LeadQuizData } from "../types";

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

// Global safety switches
let isFirebaseEnabled = false;
let dbInstance: any = null;
let authInstance: any = null;

// Handle firebase errors as required by SKILL.md
export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const currentAuth = authInstance;
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: currentAuth?.currentUser?.uid || null,
      email: currentAuth?.currentUser?.email || null,
      emailVerified: currentAuth?.currentUser?.emailVerified || null,
      isAnonymous: currentAuth?.currentUser?.isAnonymous || null,
      tenantId: currentAuth?.currentUser?.tenantId || null,
      providerInfo: currentAuth?.currentUser?.providerData?.map((provider: any) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Check configuration
const hasConfig = firebaseConfig && firebaseConfig.apiKey && firebaseConfig.projectId;

if (hasConfig) {
  try {
    const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    dbInstance = getFirestoreSDK(app, firebaseConfig.firestoreDatabaseId); // CRITICAL: The app will break without this line
    authInstance = getAuth(app);
    isFirebaseEnabled = true;

    // Validate Connection to Firestore - CRITICAL CONSTRAINT
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(dbInstance, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration: client is offline.");
        }
      }
    };
    testConnection();
  } catch (error) {
    console.warn("Firebase failed to initialize. Running in offline/localStorage mode:", error);
    isFirebaseEnabled = false;
  }
} else {
  console.log("No Firebase config found or incomplete. Falling back to secure localStorage mode.");
}

export const db = dbInstance;
export const auth = authInstance;
export { isFirebaseEnabled };

/**
 * Generate a random securely-formatted Firestore document ID
 */
export function generateId(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < 20; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Handle anonymous login helper
 */
async function ensureAuthenticated(): Promise<User | null> {
  if (!isFirebaseEnabled || !auth) return null;
  if (auth.currentUser) return auth.currentUser;
  
  try {
    const credential = await signInAnonymously(auth);
    return credential.user;
  } catch (error) {
    console.error("Failed to authenticate client anonymously:", error);
    return null;
  }
}

/**
 * Primary API to store a completed song lead
 */
export async function saveLead(leadData: LeadQuizData): Promise<{ id: string; savedToFirebase: boolean }> {
  const leadId = leadData.id || generateId();
  const timestamp = new Date().toISOString();
  
  const formattedData = {
    ...leadData,
    id: leadId,
    createdAt: timestamp,
    status: leadData.status || "pending"
  };

  // 1. Local Storage fallback saving
  try {
    const existingLeadsRaw = localStorage.getItem("melodias_de_amor_leads");
    const existingLeads = existingLeadsRaw ? JSON.parse(existingLeadsRaw) : [];
    
    // Check if updating or creating
    const index = existingLeads.findIndex((l: any) => l.id === leadId);
    if (index >= 0) {
      existingLeads[index] = formattedData;
    } else {
      existingLeads.push(formattedData);
    }
    
    localStorage.setItem("melodias_de_amor_leads", JSON.stringify(existingLeads));
    localStorage.setItem("melodias_de_amor_recent", JSON.stringify(formattedData));
  } catch (e) {
    console.error("Failed to commit lead to localStorage:", e);
  }

  // 2. Firebase saving if enabled
  let savedToFirebase = false;
  if (isFirebaseEnabled && db) {
    try {
      const user = await ensureAuthenticated();
      if (user) {
        const path = `leads/${leadId}`;
        const payload = {
          targetName: leadData.targetName,
          relationship: leadData.relationship,
          qualities: leadData.qualities,
          unforgettableMoments: leadData.unforgettableMoments,
          occasion: leadData.occasion,
          genre: leadData.genre,
          voiceType: leadData.voiceType,
          planId: leadData.planId,
          clientName: leadData.clientName,
          clientEmail: leadData.clientEmail,
          clientWhatsapp: leadData.clientWhatsapp,
          status: leadData.status || "pending",
          userId: user.uid,
          createdAt: serverTimestamp(),
        };

        // If optional values exist, include them safely matching rules
        const rulesAllowedFields: any = { ...payload };
        if (leadData.customRelationship) rulesAllowedFields.customRelationship = leadData.customRelationship;
        if (leadData.customOccasion) rulesAllowedFields.customOccasion = leadData.customOccasion;
        if (leadData.specialMessage) rulesAllowedFields.specialMessage = leadData.specialMessage;
        if (leadData.couponCode) rulesAllowedFields.couponCode = leadData.couponCode;

        await setDoc(doc(db, "leads", leadId), rulesAllowedFields);
        savedToFirebase = true;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `leads/${leadId}`);
    }
  }

  return { id: leadId, savedToFirebase };
}

/**
 * Retrieve leads stored locally for the current client (ideal for reviews!)
 */
export function getLocalLeads(): LeadQuizData[] {
  try {
    const raw = localStorage.getItem("melodias_de_amor_leads");
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}
