import React, { useState, useEffect } from "react";
import { 
  Heart, 
  Music, 
  Check, 
  Sparkles, 
  ChevronRight, 
  ChevronLeft, 
  HelpCircle, 
  Volume2, 
  VolumeX, 
  Play,
  Pause,
  Star, 
  Lock, 
  ShieldCheck, 
  Copy, 
  Plus, 
  Phone, 
  Mail, 
  User, 
  Clock, 
  ArrowRight, 
  ChevronDown, 
  Gift,
  Download
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  TESTIMONIALS, 
  FAQ_ITEMS, 
  RELATIONSHIPS, 
  OCCASIONS, 
  GENRES, 
  VOICES, 
  PLANS 
} from "./data";
import { LeadQuizData } from "./types";
import { saveLead, isFirebaseEnabled } from "./lib/firebase";
import { playStylePreview, stopAllPreviews } from "./lib/synth";
import { generateCustomLyrics, LyricsResult } from "./utils/lyricsGenerator";

const MOMENTS_ROW1 = [
  { text: "Aniversário", emoji: "🎂" },
  { text: "Casamento", emoji: "💍" },
  { text: "Namoro", emoji: "💑" },
  { text: "Amizade", emoji: "🤝" },
  { text: "Chá de revelação", emoji: "🍼" },
  { text: "Dia das Mães", emoji: "👩" },
  { text: "Dia dos Pais", emoji: "👨" },
  { text: "Novo bebê", emoji: "👶" },
];

const MOMENTS_ROW2 = [
  { text: "Festa", emoji: "🥑" },
  { text: "Homenagem", emoji: "🎵" },
  { text: "Chá de revelação", emoji: "🍼" },
  { text: "Dia das Mães", emoji: "👩" },
  { text: "Dia dos Pais", emoji: "👨" },
  { text: "Aniversário", emoji: "🎂" },
  { text: "Casamento", emoji: "💍" },
  { text: "Namoro", emoji: "💑" },
];

const MOMENTS_ROW3 = [
  { text: "Aniversário", emoji: "🎂" },
  { text: "Novo bebê", emoji: "👶" },
  { text: "Dia das Mães", emoji: "👩" },
  { text: "Dia dos Pais", emoji: "👨" },
  { text: "Amizade", emoji: "🤝" },
  { text: "Namoro", emoji: "💑" },
  { text: "Casamento", emoji: "💍" },
  { text: "Homenagem", emoji: "🎵" },
];

export default function App() {
  // Navigation states loaded from LocalStorage
  const [view, setView] = useState<"landing" | "quiz" | "checkout" | "loading" | "success">(() => {
    const saved = localStorage.getItem("melodias_de_amor_view");
    return (saved as "landing" | "quiz" | "checkout" | "loading" | "success") || "landing";
  });
  const [quizStep, setQuizStep] = useState<number>(() => {
    const saved = localStorage.getItem("melodias_de_amor_quizStep");
    return saved ? parseInt(saved, 10) : 1;
  });
  
  // Audio playback state (synth)
  const [playingGenreId, setPlayingGenreId] = useState<string | null>(null);
  const [spotifyPlaying, setSpotifyPlaying] = useState<boolean>(false);

  const toggleSpotifyPlayback = () => {
    if (spotifyPlaying) {
      stopAllPreviews();
      setSpotifyPlaying(false);
    } else {
      setPlayingGenreId(null);
      playStylePreview("acoustics");
      setSpotifyPlaying(true);
    }
  };

  // Interactive song playback and timeline states for the delivery screen
  const [trackSeconds, setTrackSeconds] = useState<number>(72); // starting at 1:12 just like reference
  const [isPlayingSong, setIsPlayingSong] = useState<boolean>(false);
  const [trackIsMuted, setTrackIsMuted] = useState<boolean>(false);

  useEffect(() => {
    let interval: any = null;
    if (isPlayingSong) {
      interval = setInterval(() => {
        setTrackSeconds(prev => {
          if (prev >= 225) { // 3:45 is 225 seconds
            setIsPlayingSong(false);
            stopAllPreviews();
            setPlayingGenreId(null);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isPlayingSong]);

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const togglePrimaryPlayback = () => {
    if (isPlayingSong) {
      setIsPlayingSong(false);
      stopAllPreviews();
      setPlayingGenreId(null);
    } else {
      setIsPlayingSong(true);
      const activeGenre = GENRES.find(g => g.name === quizData.genre) || GENRES[1];
      playStylePreview(activeGenre.previewStyle);
      setPlayingGenreId(activeGenre.id);
    }
  };

  // Form states loaded from LocalStorage
  const [quizData, setQuizData] = useState<LeadQuizData>(() => {
    const saved = localStorage.getItem("melodias_de_amor_quizData");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return {
      targetName: "",
      relationship: "Namorado(a)",
      customRelationship: "",
      qualities: "",
      unforgettableMoments: "",
      specialMessage: "",
      occasion: "Aniversário",
      customOccasion: "",
      genre: "",
      customGenre: "",
      voiceType: "Voz Feminina",
      planId: "basico",
      couponCode: "",
      clientName: "",
      clientEmail: "",
      clientWhatsapp: ""
    };
  });

  // Synchronize state changes to localStorage
  useEffect(() => {
    localStorage.setItem("melodias_de_amor_view", view);
  }, [view]);

  useEffect(() => {
    localStorage.setItem("melodias_de_amor_quizStep", quizStep.toString());
  }, [quizStep]);

  useEffect(() => {
    localStorage.setItem("melodias_de_amor_quizData", JSON.stringify(quizData));
  }, [quizData]);

  // UI state controls
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [couponApplied, setCouponApplied] = useState<boolean>(false);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<"pix" | "card">("pix");
  const [simulatedPaying, setSimulatedPaying] = useState<boolean>(false);
  const [clipboardCopied, setClipboardCopied] = useState<boolean>(false);
  const [lyricsResult, setLyricsResult] = useState<LyricsResult | null>(null);

  // Loading screen simulation states and logic
  const [loadingStep, setLoadingStep] = useState<number>(0);
  const loadingMessages = [
    "Analisando sua história...",
    "Compondo as primeiras melodias...",
    "Ajustando o tom e a emoção...",
    "Refinando a letra personalizada...",
    "Finalizando os arranjos...",
    "Quase pronto para você ouvir..."
  ];

  useEffect(() => {
    if (view !== "loading") {
      setLoadingStep(0);
      return;
    }
    
    const interval = setInterval(() => {
      setLoadingStep(prev => {
        if (prev < loadingMessages.length - 1) {
          return prev + 1;
        } else {
          clearInterval(interval);
          setTimeout(() => {
            setView("success");
            const activeGenre = GENRES.find(g => g.name === quizData.genre) || GENRES[1];
            playStylePreview(activeGenre.previewStyle);
            setPlayingGenreId(activeGenre.id);
            setIsPlayingSong(true);
            setTrackSeconds(0);
          }, 1500);
          return prev;
        }
      });
    }, 2800);

    return () => clearInterval(interval);
  }, [view, quizData.genre]);

  // Auto-fill some fields with fun helpers to make testing super fast and fun
  const handleAutoFill = () => {
    setQuizData({
      targetName: "Mariana",
      relationship: "Namorado(a)",
      customRelationship: "",
      qualities: "Ela tem o sorriso mais doce do mundo, ama tomar café com pão de queijo quentinho nas tardes chuvosas, e cuida de mim como ninguém.",
      unforgettableMoments: "A nossa viagem no ano passado para Gramado, quando nos perdemos na neblina procurando a fábrica de chocolate e rimos muito disso.",
      specialMessage: "Eu te amo infinitamente e quero construir um lar feliz com você perto das montanhas.",
      occasion: "Dia dos Namorados",
      customOccasion: "",
      genre: "Pop",
      customGenre: "",
      voiceType: "Voz Feminina",
      planId: "basico",
      couponCode: "AMOR10",
      clientName: "Pedro Henrique",
      clientEmail: "pedro.henrique@email.com",
      clientWhatsapp: "(11) 98765-4321"
    });
  };

  // Safe synthesized player trigger
  const toggleGenreSound = (genreId: string, styleStyle: string) => {
    setSpotifyPlaying(false);
    if (playingGenreId === genreId) {
      stopAllPreviews();
      setPlayingGenreId(null);
    } else {
      playStylePreview(styleStyle);
      setPlayingGenreId(genreId);
    }
  };

  // Track if synth sound gets turned off globally when leaving steps
  useEffect(() => {
    setSpotifyPlaying(false);
    return () => {
      stopAllPreviews();
    };
  }, [view, quizStep]);

  // Handle coupon validation (AMOR10 gives 10% coupon, NAMORADOS20 gives 20%)
  const applyCouponCode = () => {
    const code = quizData.couponCode?.trim().toUpperCase();
    if (code === "AMOR10") {
      setCouponApplied(true);
      setDiscountAmount(0.10); // 10% off
    } else if (code === "NAMORADOS20") {
      setCouponApplied(true);
      setDiscountAmount(0.20); // 20% off
    } else {
      alert("Cupom não encontrado ou expirado!");
      setCouponApplied(false);
      setDiscountAmount(0);
    }
  };

  // Get pricing based on chosen plan, voice type upgrade, and active coupon
  const getPricingDetails = () => {
    const selectedPlan = PLANS.find(p => p.id === quizData.planId) || PLANS[0];
    let basePrice = selectedPlan.price;
    
    // Voice upgrades
    let upgradePrice = 0;
    if (quizData.voiceType.includes("Dueto")) {
      upgradePrice = 15.00;
    }

    const subtotal = basePrice + upgradePrice;
    const discount = subtotal * discountAmount;
    const total = subtotal - discount;

    return {
      subtotal,
      discount,
      total,
      hasUpgrade: upgradePrice > 0,
      upgradeLabel: quizData.voiceType
    };
  };

  const { subtotal, discount, total, hasUpgrade } = getPricingDetails();

  // Navigation handlers
  const handleStartQuiz = () => {
    stopAllPreviews();
    setPlayingGenreId(null);
    setView("quiz");
    setQuizStep(1);
  };

  const handleNextStep = () => {
    if (quizStep === 1) {
      if (!quizData.targetName.trim()) {
        alert("Por favor, digite o nome de quem receberá a música!");
        return;
      }
    }
    if (quizStep === 2) {
      if (!quizData.qualities.trim()) {
        alert("Por favor, nos conte um pouco sobre as qualidades!");
        return;
      }
      if (!quizData.unforgettableMoments.trim()) {
        alert("Por favor, relate um momento marcante de vocês!");
        return;
      }
    }
    setQuizStep(prev => prev + 1);
  };

  const handlePrevStep = () => {
    setQuizStep(prev => prev - 1);
  };

  // Submit flow - Saves to localStorage & Firestore database if enabled
  const handleFormFinish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quizData.clientName.trim() || !quizData.clientWhatsapp.trim()) {
      alert("Por favor, preencha todos os campos de contato!");
      return;
    }

    // Compose custom lyrics beforehand so it's instantly available
    const chosenGenre = quizData.genre === "Outro Estilo" ? (quizData.customGenre || "Estilo Personalizado") : quizData.genre;
    const generated = generateCustomLyrics(
      quizData.targetName,
      quizData.relationship === "Outro" ? (quizData.customRelationship || "Especial") : quizData.relationship,
      quizData.qualities,
      quizData.unforgettableMoments,
      quizData.occasion === "Outra Ocasião" ? (quizData.customOccasion || "Ocasião") : quizData.occasion,
      chosenGenre
    );
    setLyricsResult(generated);

    // Save lead to database
    try {
      await saveLead(quizData);
    } catch (err) {
      console.error("Firebase error caught during checkout initiation:", err);
    }

    setView("checkout");
  };

  // Copy Pix Key simulator
  const handleCopyPix = () => {
    const pixKey = "0fe9881a-2bea-4fa6-9a73-24c5ba7bca1c@melodiasdeamor.com.br";
    navigator.clipboard.writeText(pixKey);
    setClipboardCopied(true);
    setTimeout(() => setClipboardCopied(false), 2000);
  };

  // Simulate payment response
  const handleSimulatedPayment = async () => {
    setSimulatedPaying(true);
    setTimeout(async () => {
      setSimulatedPaying(false);
      // Update local storage and DB with state = paid
      const updatedData = { ...quizData, status: "paid" as const };
      try {
        await saveLead(updatedData);
      } catch (e) {
        // ignore
      }
      setView("loading");
    }, 2000);
  };

  // Download personalized lyrics sheet as a beautiful keepsake text file
  const handleDownloadSong = () => {
    const title = lyricsResult?.title || "Eterno Momento";
    const textContent = `
=============================================
             ${title.toUpperCase()}
=============================================
Para: ${quizData.targetName || "Ana Maria"}
De: ${quizData.clientName || "Seu Amor"}
Gênero: ${quizData.genre || "Acústico"}
Voz: ${quizData.voiceType}
Criado em: ${new Date().toLocaleDateString('pt-BR', {day: 'numeric', month: 'long', year: 'numeric'})}

[INTRO]
${lyricsResult?.intro || "Uma suave melodia acústica se inicia no piano..."}

[VERSO 1]
${lyricsResult?.verso1 || ""}

[VERSO 2]
${lyricsResult?.verso2 || ""}

[REFRÃO COMPLETO]
${lyricsResult?.refrao || ""}

[PONTE]
${lyricsResult?.ponte || ""}

[FINAL]
${lyricsResult?.outro || ""}

---------------------------------------------
Criado com carinho por Melodias de Amor.
Agradecemos por compartilhar sua história conosco!
=============================================
`;
    const blob = new Blob([textContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${title.toLowerCase().replace(/\s+/g, "_")}_letra_exclusiva.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-surface-bg text-brand-800 font-sans antialiased overflow-x-hidden">
      
      {/* NAVIGATION HEADER */}
      <header className="sticky top-0 z-30 bg-[#fff8f4]/95 backdrop-blur-md border-b border-[#c9a96e]/30 py-2.5 px-3 sm:py-4 sm:px-6 flex items-center justify-between">
        <div id="nav-brand-logo" className="flex items-center gap-1.5 sm:gap-2 cursor-pointer" onClick={() => setView("landing")}>
          <div className="w-7 h-7 sm:w-10 sm:h-10 rounded-full bg-[#c9a96e]/10 border border-[#c9a96e]/40 flex items-center justify-center">
            <Heart className="w-4 h-4 sm:w-5 sm:h-5 text-[#c9a96e] fill-[#c9a96e]/30" />
          </div>
          <div>
            <span className="font-serif text-base sm:text-2xl text-[#745a27] tracking-tight font-medium whitespace-nowrap">Melodias de Amor</span>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4 shrink-0">
          {view === "landing" ? (
            <>
              <nav className="hidden md:flex items-center gap-6 text-[#745a27] text-sm">
                <a href="#como-funciona" className="hover:text-[#c9a96e] transition duration-200">Como funciona</a>
                <a href="#depoimentos" className="hover:text-[#c9a96e] transition duration-200">Depoimentos</a>
              </nav>
              <button 
                id="cta-header-start"
                onClick={handleStartQuiz}
                className="px-3 py-1.5 sm:px-6 sm:py-2 rounded-full text-[10px] sm:text-xs md:text-sm font-semibold bg-[#745a27] hover:bg-[#5a4312] text-white transition-all duration-300 transform hover:-translate-y-0.5 flex items-center gap-1 sm:gap-1.5 touch-manipulation whitespace-nowrap"
              >
                <Music className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#e8c97a]" />
                <span className="hidden xs:inline">Criar minha música</span>
                <span className="xs:hidden">Criar música</span>
              </button>
            </>
          ) : (
            <button 
              onClick={() => {
                if (confirm("Tem certeza que deseja voltar para a Página Principal? Seus dados não finalizados serão redefinidos.")) {
                  setView("landing");
                }
              }}
              className="px-3 py-1.5 text-[10px] sm:text-xs font-semibold text-[#745a27] hover:text-[#c9a96e] transition whitespace-nowrap"
            >
              Voltar ao Início
            </button>
          )}
        </div>
      </header>

      {/* LANDING PAGE VIEW */}
      {view === "landing" && (
        <main className="pb-16 animate-fadeIn">
          
          {/* HERO SECTION */}
          <section className="relative px-6 py-12 md:py-20 max-w-4xl mx-auto flex flex-col items-center justify-center text-center">
            <div className="space-y-6 text-center max-w-3xl mx-auto flex flex-col items-center">
              
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#fdf6e8] border border-[#c9a96e]/40 rounded-full text-[#745a27] text-[10px] sm:text-xs font-semibold uppercase tracking-wider">
                <Gift className="w-3.5 h-3.5 text-[#c9a96e] scale-85" />
                <span>A música que só existe para você</span>
              </div>
              
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#1a1208] leading-tight font-medium tracking-tight">
                Essa música sempre me faz chorar <span className="text-[#745a27] italic font-normal">do começo ao fim</span>
              </h1>
              
              <p className="text-brand-800/80 text-sm sm:text-lg max-w-xl mx-auto font-light leading-relaxed px-4">
                Sua história de amor transformada em uma música personalizada exclusiva
              </p>

              {/* CTA and quick reassurance */}
              <div className="flex flex-col sm:flex-row items-center gap-4 justify-center pt-4">
                <button
                  id="hero-cta-button"
                  onClick={handleStartQuiz}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-full text-sm font-medium bg-[#745a27] hover:bg-[#5a4312] text-white transition-all duration-300 transform hover:-translate-y-0.5 flex items-center justify-center gap-2 cursor-pointer shadow-md hover:shadow-brand-300"
                >
                  <span>Criar minha música personalizada</span>
                  <ChevronRight className="w-4 h-4 text-[#e8c97a]" />
                </button>
                <p className="text-xs text-[#745a27] font-semibold tracking-wide flex items-center justify-center gap-1 shrink-0">
                  <Clock className="w-3.5 h-3.5 text-[#c9a96e]" />
                  <span>Feito com amor e carinho em 24h</span>
                </p>
              </div>

              {/* Mini testimonial with stars and avatars */}
              <div id="mini-testimonial-badge" className="pt-3.5 flex flex-col items-center space-y-1.5">
                {/* Stars */}
                <div className="flex gap-0.5 text-[#e8c97a]">
                  <Star className="w-3 h-3 fill-[#e8c97a] text-[#e8c97a]" />
                  <Star className="w-3 h-3 fill-[#e8c97a] text-[#e8c97a]" />
                  <Star className="w-3 h-3 fill-[#e8c97a] text-[#e8c97a]" />
                  <Star className="w-3 h-3 fill-[#e8c97a] text-[#e8c97a]" />
                  <Star className="w-3 h-3 fill-[#e8c97a] text-[#e8c97a]" />
                </div>
                
                {/* Overlapping Avatars */}
                <div className="flex items-center -space-x-2">
                  <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=120&h=120" className="w-6.5 h-6.5 rounded-full border border-white object-cover" referrerPolicy="no-referrer" />
                  <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=120&h=120" className="w-6.5 h-6.5 rounded-full border border-white object-cover" referrerPolicy="no-referrer" />
                  <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120&h=120" className="w-6.5 h-6.5 rounded-full border border-white object-cover" referrerPolicy="no-referrer" />
                  <img src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=120&h=120" className="w-6.5 h-6.5 rounded-full border border-white object-cover" referrerPolicy="no-referrer" />
                  <div className="w-6.5 h-6.5 rounded-full bg-[#fdf6e8] text-[#745a27] text-[8px] font-bold flex items-center justify-center border border-white">+998</div>
                </div>

                {/* Subtitle text */}
                <p className="text-xs font-sans font-medium text-[#745a27]/80 tracking-wide text-center">
                  Amado por 1000+ famílias
                </p>

                {/* Elegant romantic heart divider matching the design guidelines */}
                <div className="flex items-center justify-center gap-2 pt-1 w-full max-w-[150px]">
                  <div className="h-[1px] bg-gradient-to-r from-transparent to-[#c9a96e]/30 grow"></div>
                  <Heart className="w-2 h-2 text-[#c9a96e]/50 fill-[#c9a96e]/20" />
                  <div className="h-[1px] bg-gradient-to-l from-transparent to-[#c9a96e]/30 grow"></div>
                </div>
              </div>
            </div>
          </section>

          {/* HOW IT WORKS SECTION */}
          <section id="como-funciona" className="bg-white py-12 sm:py-20 px-6 border-y border-[#c9a96e]/30">
            <div className="max-w-7xl mx-auto text-center space-y-10">
              <div className="space-y-2">
                <span className="text-[10px] sm:text-xs font-mono font-bold tracking-widest text-[#745a27] uppercase bg-[#fdf6e8] px-2.5 py-1 rounded-full border border-[#c9a96e]/30 inline-block">Processo Artesanal</span>
                <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-medium text-[#1a1208] tracking-tight">Como funciona o processo?</h2>
              </div>

              <div className="grid md:grid-cols-3 gap-8 pt-4">
                {/* Step 1 */}
                <div className="relative p-6 sm:p-8 rounded-lg bg-[#fff8f4] border border-[#c9a96e]/20 hover:border-[#c9a96e]/60 transition-all duration-300">
                  <div className="absolute top-4 right-4 text-4xl font-serif italic text-[#c9a96e]/30 font-bold">1</div>
                  <div className="w-12 h-12 rounded-lg bg-white border border-[#c9a96e]/40 flex items-center justify-center text-[#c9a96e] font-bold mb-6">
                    <Heart className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif font-semibold text-lg text-[#1a1208] mb-2 text-left">Compartilhe sua história</h3>
                  <p className="text-xs sm:text-sm text-brand-800/80 leading-relaxed font-light text-left">
                    Conte para nós suas memórias especiais, os apelidos carinhosos e os momentos que fizeram vocês rirem ou chorarem juntos.
                  </p>
                </div>

                {/* Step 2 */}
                <div className="relative p-6 sm:p-8 rounded-lg bg-[#fff8f4] border border-[#c9a96e]/20 hover:border-[#c9a96e]/60 transition-all duration-300">
                  <div className="absolute top-4 right-4 text-4xl font-serif italic text-[#c9a96e]/30 font-bold">2</div>
                  <div className="w-12 h-12 rounded-lg bg-white border border-[#c9a96e]/40 flex items-center justify-center text-[#c9a96e] font-bold mb-6">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif font-semibold text-lg text-[#1a1208] mb-2 text-left">Nós criamos</h3>
                  <p className="text-xs sm:text-sm text-brand-800/80 leading-relaxed font-light text-left">
                    Letras e melodias originais criadas a partir da sua história. Nossos intérpretes gravam vozes reais no compasso musical ideal.
                  </p>
                </div>

                {/* Step 3 */}
                <div className="relative p-6 sm:p-8 rounded-lg bg-[#fff8f4] border border-[#c9a96e]/20 hover:border-[#c9a96e]/60 transition-all duration-300">
                  <div className="absolute top-4 right-4 text-4xl font-serif italic text-[#c9a96e]/30 font-bold">3</div>
                  <div className="w-12 h-12 rounded-lg bg-white border border-[#c9a96e]/40 flex items-center justify-center text-[#c9a96e] font-bold mb-6">
                    <Music className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif font-semibold text-lg text-[#1a1208] mb-2 text-left">Receba e compartilhe</h3>
                  <p className="text-xs sm:text-sm text-brand-800/80 leading-relaxed font-light text-left">
                    Uma página personalizada para compartilhar e ver a reação de quem você ama, além do arquivo em MP3 puro de alta fidelidade.
                  </p>
                </div>
              </div>

              {/* Moments Marquee Section mimicking the screenshot provided */}
              <div id="moments-marquee-section" className="mt-12 bg-[#fff8f4] border border-[#c9a96e]/30 rounded-2xl p-6 sm:p-8 relative overflow-hidden text-center shadow-[0_4px_20px_-4px_rgba(201,169,110,0.06)] max-w-4xl mx-auto">
                {/* Title styled with golden caps */}
                <span className="text-[10px] sm:text-xs font-mono font-bold tracking-widest text-[#745a27] uppercase block mb-4.5 px-0.5 text-center">
                  Para cada momento
                </span>

                {/* Left & Right gradient masks for elegant fading edges */}
                <div className="absolute top-0 bottom-0 left-0 w-20 bg-gradient-to-r from-[#fff8f4] via-[#fff8f4]/80 to-transparent z-10 pointer-events-none"></div>
                <div className="absolute top-0 bottom-0 right-0 w-20 bg-gradient-to-l from-[#fff8f4] via-[#fff8f4]/80 to-transparent z-10 pointer-events-none"></div>

                <div className="space-y-3.5 relative overflow-hidden">
                  {/* Row 1 - Left direction */}
                  <div className="overflow-hidden w-full relative">
                    <div className="flex select-none w-full">
                      <div className="flex shrink-0 gap-2.5 min-w-full animate-marquee-left pr-2.5">
                        {MOMENTS_ROW1.map((item, idx) => (
                          <div key={`mr1-${idx}`} className="inline-flex items-center gap-1.5 px-4.5 py-2 bg-white border border-[#c9a96e]/20 rounded-full text-xs font-sans font-medium text-[#1a1208] shadow-xs shrink-0">
                            <span>{item.emoji}</span>
                            <span className="font-semibold tracking-tight text-brand-800/95">{item.text}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex shrink-0 gap-2.5 min-w-full animate-marquee-left pr-2.5" aria-hidden="true">
                        {MOMENTS_ROW1.map((item, idx) => (
                          <div key={`mr1-dup-${idx}`} className="inline-flex items-center gap-1.5 px-4.5 py-2 bg-white border border-[#c9a96e]/20 rounded-full text-xs font-sans font-medium text-[#1a1208] shadow-xs shrink-0">
                            <span>{item.emoji}</span>
                            <span className="font-semibold tracking-tight text-brand-800/95">{item.text}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Row 2 - Right direction */}
                  <div className="overflow-hidden w-full relative">
                    <div className="flex select-none w-full">
                      <div className="flex shrink-0 gap-2.5 min-w-full animate-marquee-right pr-2.5">
                        {MOMENTS_ROW2.map((item, idx) => (
                          <div key={`mr2-${idx}`} className="inline-flex items-center gap-1.5 px-4.5 py-2 bg-white border border-[#c9a96e]/20 rounded-full text-xs font-sans font-medium text-[#1a1208] shadow-xs shrink-0">
                            <span>{item.emoji}</span>
                            <span className="font-semibold tracking-tight text-brand-800/95">{item.text}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex shrink-0 gap-2.5 min-w-full animate-marquee-right pr-2.5" aria-hidden="true">
                        {MOMENTS_ROW2.map((item, idx) => (
                          <div key={`mr2-dup-${idx}`} className="inline-flex items-center gap-1.5 px-4.5 py-2 bg-white border border-[#c9a96e]/20 rounded-full text-xs font-sans font-medium text-[#1a1208] shadow-xs shrink-0">
                            <span>{item.emoji}</span>
                            <span className="font-semibold tracking-tight text-brand-800/95">{item.text}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Row 3 - Left direction but speed offset */}
                  <div className="overflow-hidden w-full relative">
                    <div className="flex select-none w-full">
                      <div className="flex shrink-0 gap-2.5 min-w-full animate-marquee-left-fast pr-2.5">
                        {MOMENTS_ROW3.map((item, idx) => (
                          <div key={`mr3-${idx}`} className="inline-flex items-center gap-1.5 px-4.5 py-2 bg-white border border-[#c9a96e]/20 rounded-full text-xs font-sans font-medium text-[#1a1208] shadow-xs shrink-0">
                            <span>{item.emoji}</span>
                            <span className="font-semibold tracking-tight text-brand-800/95">{item.text}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex shrink-0 gap-2.5 min-w-full animate-marquee-left-fast pr-2.5" aria-hidden="true">
                        {MOMENTS_ROW3.map((item, idx) => (
                          <div key={`mr3-dup-${idx}`} className="inline-flex items-center gap-1.5 px-4.5 py-2 bg-white border border-[#c9a96e]/20 rounded-full text-xs font-sans font-medium text-[#1a1208] shadow-xs shrink-0">
                            <span>{item.emoji}</span>
                            <span className="font-semibold tracking-tight text-brand-800/95">{item.text}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>


          {/* TESTIMONIALS SECTION */}
          <section id="depoimentos" className="bg-[#fdf6e8] py-16 sm:py-24 px-6 border-y border-[#c9a96e]/30">
            <div className="max-w-7xl mx-auto space-y-12">
              <div className="text-center space-y-3">
                <span className="text-xs font-mono font-bold tracking-widest text-[#745a27] uppercase bg-white px-3.5 py-1.5 rounded-full border border-[#c9a96e]/30 inline-block">Corações que se emocionaram</span>
                <h2 className="font-serif text-3xl sm:text-4xl font-medium text-[#1a1208] tracking-tight">O que estão dizendo</h2>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 pt-4">
                {TESTIMONIALS.map((t, idx) => (
                  <div key={idx} className="bg-white p-6 rounded-lg border border-[#c9a96e]/30 flex flex-col justify-between hover:border-[#c9a96e]/70 transition-all duration-300">
                    <div className="space-y-4">
                      {/* Rating stars inside design system */}
                      <div className="flex text-[#c9a96e] gap-0.5">
                        {Array.from({ length: t.rating }).map((_, i) => (
                          <span key={i} className="text-sm select-none">★</span>
                        ))}
                      </div>
                      <p className="text-xs sm:text-sm text-brand-800/90 font-light leading-relaxed italic">
                        "{t.text}"
                      </p>
                    </div>

                    <div className="mt-6 flex items-center gap-3 border-t border-[#c9a96e]/20 pt-4">
                      <div className="w-10 h-10 rounded-full bg-[#fdf6e8] border border-[#c9a96e]/30 flex items-center justify-center text-[#745a27] font-bold text-xs uppercase">
                        {t.name.split(" ").map(n => n[0]).join("")}
                      </div>
                      <div>
                        <h4 className="text-xs font-semibold text-[#1a1208]">{t.name}</h4>
                        <p className="text-[10px] text-[#745a27]/80 font-light">{t.relationship}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* O QUE VOCÊ VAI RECEBER SECTION */}
          <section className="bg-[#0f0b07] text-white p-6 py-18 sm:py-24 border-t border-[#c9a96e]/20 relative overflow-hidden">
            {/* Elegant faint gold gradient in the background to avoid plain black */}
            <div className="absolute inset-0 bg-radial-gradient from-brand-700/10 via-transparent to-transparent opacity-40 pointer-events-none"></div>

            <div className="max-w-xl mx-auto space-y-10 text-left relative z-10">
              <div className="space-y-4">
                <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight leading-tight text-white animate-fadeIn">
                  O que você vai <br className="hidden sm:block" /> receber
                </h2>
                <p className="text-white/60 max-w-sm text-xs sm:text-sm font-light leading-relaxed">
                  Assim que sua música estiver pronta, você recebe um e-mail com o acesso para ouvir igual ao exemplo abaixo.
                </p>
              </div>

              {/* Bullet list of benefits with gold dots */}
              <div className="space-y-6">
                <div className="flex items-start gap-3">
                  <span className="w-2 h-2 rounded-full bg-[#be8666] mt-1.5 shrink-0 shadow-sm shadow-[#be8666]/50"></span>
                  <div>
                    <h4 className="text-sm sm:text-base font-semibold text-white">
                      Música com qualidade profissional
                    </h4>
                    <p className="text-white/40 text-xs sm:text-sm font-light mt-0.5">
                      Produção de alto nível, pronta para compartilhar
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="w-2 h-2 rounded-full bg-[#be8666] mt-1.5 shrink-0 shadow-sm shadow-[#be8666]/50"></span>
                  <div>
                    <h4 className="text-sm sm:text-base font-semibold text-white">
                      Letra personalizada
                    </h4>
                    <p className="text-white/40 text-xs sm:text-sm font-light mt-0.5">
                      Criada a partir da sua história, com todos os detalhes que importam
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="w-2 h-2 rounded-full bg-[#be8666] mt-1.5 shrink-0 shadow-sm shadow-[#be8666]/50"></span>
                  <div>
                    <h4 className="text-sm sm:text-base font-semibold text-white">
                      Entrega em 5 dias
                    </h4>
                    <p className="text-white/40 text-xs sm:text-sm font-light mt-0.5">
                      Sua música final pronta em até cinco dias
                    </p>
                  </div>
                </div>
              </div>

              {/* Elegant Spotify-reminiscent interactive music player widget */}
              <div className="pt-4 relative">
                {/* Floating Spotify wave equalizer badge when music is active */}
                {spotifyPlaying && (
                  <div className="absolute -top-4.5 left-10 bg-[#745a27]/95 text-[#fdf6e8] text-[9px] font-mono font-bold tracking-widest uppercase py-1 px-3.5 rounded-full border border-[#c9a96e]/40 flex items-center gap-2 shadow-lg backdrop-blur-xs z-20">
                    <div className="flex items-end gap-0.5 h-2.5 w-3 shrink-0">
                      <span className="w-[1.5px] bg-white rounded-full animate-equalizer-1"></span>
                      <span className="w-[1.5px] bg-[#be8666] rounded-full animate-equalizer-2"></span>
                      <span className="w-[1.5px] bg-white rounded-full animate-equalizer-3"></span>
                    </div>
                    <span>Tocando Demo</span>
                  </div>
                )}

                <div className="bg-[#120e0a] border border-[#c9a96e]/25 rounded-full py-2 px-3.5 sm:py-2.5 sm:px-5 flex items-center shadow-2xl relative overflow-hidden max-w-full inline-flex">
                  <div className="flex items-center gap-3">
                    {/* Faded Left Arrow */}
                    <ChevronLeft className="w-4 h-4 text-white/20 select-none shrink-0" />

                    {/* Circle Play/Pause Button in salmon/terracotta styled exactly to match the image */}
                    <button
                      onClick={toggleSpotifyPlayback}
                      className={`w-12 h-12 sm:w-13 sm:h-13 rounded-full flex items-center justify-center transition-all duration-300 relative shrink-0 cursor-pointer ${
                        spotifyPlaying 
                          ? "bg-[#745a27] text-white hover:bg-[#5a4312] shadow-[0_0_15px_rgba(116,90,39,0.3)]" 
                          : "bg-[#be8666] hover:bg-[#c99577] text-white shadow-[0_0_18px_rgba(190,134,102,0.45)]"
                      }`}
                      title={spotifyPlaying ? "Pausar música" : "Ouvir demonstração"}
                    >
                      {spotifyPlaying ? (
                        <Pause className="w-4.5 h-4.5 text-white" />
                      ) : (
                        <Play className="w-4.5 h-4.5 fill-white text-white translate-x-0.5" />
                      )}
                    </button>

                    {/* Faded Right Arrow */}
                    <ChevronRight className="w-4 h-4 text-white/20 select-none shrink-0" />
                  </div>

                  {/* Vertical separator line */}
                  <div className="h-8 w-[1px] bg-white/20 ml-3 mr-4.5 shrink-0 sm:ml-4 sm:mr-5"></div>

                  {/* High conversion CTA section perfectly matching the image */}
                  <button
                    onClick={handleStartQuiz}
                    className="flex items-center gap-1.5 sm:gap-2.5 group cursor-pointer pr-1 sm:pr-2.5 text-left"
                  >
                    <span className="text-xs sm:text-base font-sans font-extrabold text-white tracking-wide transition-colors group-hover:text-[#c9a96e] whitespace-nowrap">
                      Criar música personalizada
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-[#be8666] transform transition-transform group-hover:translate-x-1 shrink-0" />
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* FAQ ACCORDION SECTION */}
          <section className="bg-white p-6 py-16 sm:py-24 border-t border-[#c9a96e]/20">
            <div className="max-w-3xl mx-auto space-y-12">
              <div className="text-center space-y-3">
                <span className="text-xs font-mono font-bold tracking-widest text-[#745a27] uppercase bg-[#fdf6e8] px-3.5 py-1.5 rounded-full border border-[#c9a96e]/30 inline-block">Dúvidas Frequentes</span>
                <h2 className="font-serif text-3xl sm:text-4xl font-medium text-[#1a1208] tracking-tight">Perguntas Comuns</h2>
                <p className="text-brand-800/70 text-xs sm:text-sm font-light">
                  Leia as respostas rápidas fornecidas pelo nosso time artístico de gravação.
                </p>
              </div>

              <div className="space-y-4">
                {FAQ_ITEMS.map((item, index) => (
                  <div 
                    key={index} 
                    className="bg-[#fff8f4] rounded-lg border border-[#c9a96e]/25 overflow-hidden"
                  >
                    <button
                      onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                      className="w-full text-left p-5 flex items-center justify-between font-serif font-semibold text-[#1a1208] text-sm sm:text-base hover:bg-[#fdf6e8]/40 transition cursor-pointer"
                    >
                      <span>{item.question}</span>
                      <ChevronDown 
                        className={`w-4 h-4 text-[#c9a96e] transition-transform duration-300 ${activeFaq === index ? "rotate-180" : ""}`} 
                      />
                    </button>
                    
                    <div 
                      className={`transition-all duration-300 ease-in-out ${
                        activeFaq === index ? "max-h-96 opacity-100 border-t border-[#c9a96e]/15" : "max-h-0 opacity-0 pointer-events-none"
                      }`}
                    >
                      <p className="p-5 text-xs sm:text-sm text-brand-800/80 leading-relaxed font-light">
                        {item.answer}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* FINAL CTA SECTION WITH VINYL GLOSSY GROOVES BACKGROUND */}
          <section className="relative overflow-hidden py-24 bg-[#fdf6e8] border-t border-[#c9a96e]/20 text-center">
            {/* Glossy vinyl record groove visual effects mimicking the reference image precisely */}
            <div className="absolute inset-0 pointer-events-none opacity-[0.22] select-none z-0 overflow-hidden">
              {/* Massive concentric golden rings */}
              <div className={`absolute -right-32 -bottom-32 w-[650px] h-[650px] sm:w-[850px] sm:h-[850px] border-2 border-[#745a27]/30 rounded-full transition-transform duration-[40s] ease-linear ${spotifyPlaying ? 'animate-spin-slow' : ''}`}>
                <div className="absolute inset-4 border border-[#745a27]/20 rounded-full"></div>
                <div className="absolute inset-10 border border-[#745a27]/10 rounded-full"></div>
                <div className="absolute inset-16 border border-[#c9a96e]/30 rounded-full"></div>
                <div className="absolute inset-28 border border-[#c9a96e]/15 rounded-full"></div>
                <div className="absolute inset-40 border border-[#745a27]/25 rounded-full"></div>
                <div className="absolute inset-60 border border-[#745a27]/15 rounded-full"></div>
                <div className="absolute inset-80 border-2 border-[#c9a96e]/30 rounded-full"></div>
                <div className="absolute inset-[400px] border border-[#745a27]/20 rounded-full"></div>
              </div>
              <div className={`absolute -left-48 -top-48 w-[500px] h-[500px] border-2 border-[#745a27]/25 rounded-full transition-transform duration-[50s] ease-linear ${spotifyPlaying ? 'animate-spin-slow' : ''}`}>
                <div className="absolute inset-8 border border-[#745a27]/15 rounded-full"></div>
                <div className="absolute inset-20 border border-[#c9a96e]/25 rounded-full"></div>
                <div className="absolute inset-36 border border-[#745a27]/10 rounded-full"></div>
              </div>
            </div>

            <div className="max-w-4xl mx-auto px-6 relative z-10 space-y-10 flex flex-col items-center">
              <div className="space-y-4 max-w-xl mx-auto">
                <span className="text-[10px] sm:text-xs font-mono font-bold tracking-widest text-[#745a27] uppercase bg-white px-3.5 py-1.5 rounded-full border border-[#c9a96e]/30 inline-block shadow-xs">
                  Eternize seu amor em forma de canção
                </span>
                <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-medium text-[#1a1208] tracking-tight leading-tight">
                  Sua história merece <br className="hidden sm:block" /> uma trilha sonora própria
                </h2>
                <p className="text-brand-800/70 text-xs sm:text-sm font-light max-w-md mx-auto leading-relaxed">
                  Não deixe esse sentimento passar em branco. Comece agora mesmo a criar uma canção exclusiva que será gravada para sempre nos corações.
                </p>
              </div>

              {/* Polished Play / Customize Pill Button centered */}
              <div className="pt-2 relative">
                {/* Vinyl Record Center Pin dot decoration like in reference image at bottom-right of the player */}
                <div className="absolute -bottom-10 -right-8 w-2 h-2 bg-neutral-400 opacity-60 rounded-full shadow-[0_0_8px_rgba(255,255,255,0.9)] z-0"></div>

                {/* Floating active equalizer indicator */}
                {spotifyPlaying && (
                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-[#745a27] text-white text-[9px] font-mono font-bold tracking-widest uppercase py-1 px-3 rounded-full border border-[#c9a96e]/40 flex items-center gap-1.5 shadow-md">
                    <div className="flex items-end gap-0.5 h-2 w-2.5 shrink-0">
                      <span className="w-[1.5px] bg-white rounded-full animate-equalizer-2"></span>
                      <span className="w-[1.5px] bg-[#be8666] rounded-full animate-equalizer-3"></span>
                      <span className="w-[1.5px] bg-white rounded-full animate-equalizer-1"></span>
                    </div>
                    <span>Demonstração Ativa</span>
                  </div>
                )}

                <div className="bg-[#120e0a] border border-[#c9a96e]/25 rounded-full py-2.5 px-4 sm:py-3 sm:px-6 flex items-center shadow-xl relative overflow-hidden z-10 max-w-full inline-flex">
                  <div className="flex items-center gap-3">
                    {/* Faded Left Arrow */}
                    <ChevronLeft className="w-4 h-4 text-white/20 select-none shrink-0" />

                    {/* Play/Pause control inside the Pill */}
                    <button
                      onClick={toggleSpotifyPlayback}
                      className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center transition-all duration-300 relative shrink-0 cursor-pointer ${
                        spotifyPlaying 
                          ? "bg-[#745a27] text-white hover:bg-[#5a4312] shadow-[0_0_15px_rgba(116,90,39,0.3)]" 
                          : "bg-[#be8666] hover:bg-[#c99577] text-white shadow-[0_0_18px_rgba(190,134,102,0.45)]"
                      }`}
                      title={spotifyPlaying ? "Pausar música" : "Ouvir demonstração"}
                    >
                      {spotifyPlaying ? (
                        <Pause className="w-4 h-4 text-white" />
                      ) : (
                        <Play className="w-4 h-4 fill-white text-white translate-x-0.5" />
                      )}
                    </button>

                    {/* Faded Right Arrow */}
                    <ChevronRight className="w-4 h-4 text-white/20 select-none shrink-0" />
                  </div>

                  {/* Vertical separation line */}
                  <div className="h-8 w-[1px] bg-white/20 ml-3 mr-4.5 shrink-0 sm:ml-4 sm:mr-5"></div>

                  {/* Redirection / Quiz trigger CTA */}
                  <button
                    onClick={handleStartQuiz}
                    className="flex items-center gap-1.5 sm:gap-2.5 group cursor-pointer pr-1 text-left"
                  >
                    <span className="text-xs sm:text-base font-sans font-extrabold text-white tracking-wide transition-colors group-hover:text-[#c9a96e] whitespace-nowrap">
                      Criar música personalizada
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-[#be8666] transform transition-transform group-hover:translate-x-1 shrink-0" />
                  </button>
                </div>
              </div>

            </div>
          </section>
        </main>
      )}

      {/* INTERACTIVE QUIZ FUNNEL VIEW */}
      {view === "quiz" && (
        <main className="max-w-3xl mx-auto px-6 py-10 animate-fadeIn">
          
          {/* Progress bar container */}
          <div className="space-y-3 mb-8">
            <div className="flex items-center justify-between text-xs font-bold text-[#745a27] uppercase tracking-widest font-mono">
              <span className="text-[#745a27]">Composição em Progresso</span>
              <span>Etapa {quizStep} de 5</span>
            </div>
            
            <div className="h-2 w-full bg-[#fdebda] rounded-full overflow-hidden border border-[#c9a96e]/20">
              <div 
                className="h-full bg-gradient-to-r from-[#c9a96e] to-[#745a27] transition-all duration-500"
                style={{ width: `${(quizStep / 5) * 100}%` }}
              ></div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 sm:p-10 border border-[#c9a96e]/30 shadow-xs">
            
            {/* STEP 1: BASIC INFORMATION */}
            {quizStep === 1 && (
              <div className="space-y-5 animate-slideIn">
                <div className="text-left w-full">
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#1a1208] tracking-tight">Para quem vai essa homenagem?</h2>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-black block">Nome da pessoa</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ex: Mariana, Mãe, Lucas..." 
                      value={quizData.targetName}
                      onChange={(e) => setQuizData({ ...quizData, targetName: e.target.value })}
                      className="w-full px-5 py-3.5 rounded-[20px] border border-[#e3dcd3] focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 text-sm bg-white text-gray-800 placeholder-gray-400 font-sans transition-all shadow-xs"
                    />
                  </div>

                  <AnimatePresence>
                    {quizData.targetName.trim() && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-2 overflow-hidden pt-1"
                      >
                        <label className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-black block mt-2">
                          Quem é {quizData.targetName} pra você?
                        </label>
                        
                        {/* Pills Grid */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                          {RELATIONSHIPS.map((rel) => {
                            const isSelected = quizData.relationship === rel;
                            return (
                              <button
                                key={rel}
                                type="button"
                                onClick={() => setQuizData({ ...quizData, relationship: rel })}
                                className={`py-3 px-2 text-xs rounded-full border font-medium text-center transition-all ${
                                  isSelected 
                                    ? "bg-[#745a27] text-white border-[#745a27]" 
                                    : "bg-white text-brand-800 border-[#c9a96e]/30 hover:bg-[#fdf6e8]"
                                }`}
                              >
                                {rel}
                              </button>
                            );
                          })}
                        </div>

                        {/* Custom relationship field if "Outro" is selected */}
                        {quizData.relationship === "Outro" && (
                          <div className="pt-3 animate-slideIn">
                            <label className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-[#745a27]/70 block mb-1">Especifique a relação:</label>
                            <input
                              type="text"
                              placeholder="Ex: Tia querida, Mentor, Afilhado..."
                              value={quizData.customRelationship || ""}
                              onChange={(e) => setQuizData({ ...quizData, customRelationship: e.target.value })}
                              className="w-full px-5 py-3.5 rounded-[20px] border border-[#e3dcd3] focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 text-sm bg-white text-gray-800 placeholder-gray-400 font-sans transition-all shadow-xs"
                            />
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="pt-8 border-t border-[#c9a96e]/20 flex justify-end">
                  <button 
                    id="btn-next-step-1"
                    onClick={handleNextStep}
                    disabled={!quizData.targetName.trim() || !quizData.relationship}
                    className="px-8 py-3.5 rounded-full font-medium text-sm bg-[#745a27] hover:bg-[#5a4312] disabled:opacity-50 disabled:cursor-not-allowed text-white flex items-center justify-center gap-1 transition cursor-pointer"
                  >
                    <span>Continuar</span>
                    <ChevronRight className="w-4 h-4 text-[#e8c97a]" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: HISTORIES AND EMOTION */}
            {quizStep === 2 && (
              <div className="space-y-6 animate-slideIn">
                <div className="space-y-2 text-center sm:text-left">
                  <h2 className="font-serif text-2xl font-bold text-[#1a1208] tracking-tight">O que torna {quizData.targetName || "ele(a)"} tão especial?</h2>
                  <p className="text-xs text-[#745a27] font-light">Diga o que você mais gosta e as qualidades que você mais admira</p>
                </div>

                <div className="space-y-5 pt-4">
                  
                  {/* Qualities text block */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-baseline">
                      <label className="text-xs font-semibold uppercase tracking-wider text-[#745a27]/90 block">Qualidades que você ama</label>
                      <span className="text-[10px] text-[#745a27]/60 font-medium">
                        {quizData.qualities.trim().length >= 10 ? "✓ Pronto" : "mín. 10 letras"}
                      </span>
                    </div>
                    <textarea 
                      required
                      rows={4}
                      placeholder="Ex: Tem o sorriso mais lindo, é super alegre, dedicada e ama passar o tempo com a família..." 
                      value={quizData.qualities}
                      onChange={(e) => setQuizData({ ...quizData, qualities: e.target.value })}
                      className="w-full p-5 sm:p-6 rounded-[20px] border border-[#e3dcd3] focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 text-sm bg-white text-gray-800 placeholder-gray-400 font-sans leading-relaxed transition-all shadow-xs"
                    />
                  </div>

                  <AnimatePresence>
                    {quizData.qualities.trim().length >= 10 && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-2 overflow-hidden pt-1"
                      >
                        <div className="flex justify-between items-baseline">
                          <label className="text-xs font-semibold uppercase tracking-wider text-[#745a27]/90 block">Momentos ou histórias juntos</label>
                          <span className="text-[10px] text-[#745a27]/60 font-medium">
                            {quizData.unforgettableMoments.trim().length >= 10 ? "✓ Pronto" : "mín. 10 letras"}
                          </span>
                        </div>
                        <textarea 
                          required
                          rows={4}
                          placeholder="Ex: Nossa viagem para a praia, quando tomamos sorvete rindo sob a chuva e conversamos até o amanhecer..." 
                          value={quizData.unforgettableMoments}
                          onChange={(e) => setQuizData({ ...quizData, unforgettableMoments: e.target.value })}
                          className="w-full p-5 sm:p-6 rounded-[20px] border border-[#e3dcd3] focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 text-sm bg-white text-gray-800 placeholder-gray-400 font-sans leading-relaxed transition-all shadow-xs"
                        />
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <AnimatePresence>
                    {quizData.qualities.trim().length >= 10 && quizData.unforgettableMoments.trim().length >= 10 && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-2 overflow-hidden pt-1"
                      >
                        <div className="flex justify-between items-baseline">
                          <label className="text-xs font-semibold uppercase tracking-wider text-[#745a27]/80 block">Uma mensagem especial <span className="text-[10px] text-brand-800/40 font-light">(opcional)</span></label>
                        </div>
                        <textarea 
                          rows={3}
                          placeholder="O que você quer que essa pessoa saiba, sinta ou lembre?"
                          value={quizData.specialMessage}
                          onChange={(e) => setQuizData({ ...quizData, specialMessage: e.target.value })}
                          className="w-full p-5 rounded-[20px] border border-[#e3dcd3] focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 text-sm bg-white text-gray-800 placeholder-gray-400 font-sans leading-relaxed transition-all shadow-xs"
                        />
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <AnimatePresence>
                    {quizData.qualities.trim().length >= 10 && quizData.unforgettableMoments.trim().length >= 10 && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-2 overflow-hidden pt-1"
                      >
                        <label className="text-xs font-semibold uppercase tracking-wider text-[#745a27] block">Qual é a ocasião?</label>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {OCCASIONS.map((occ) => {
                            const isSelected = quizData.occasion === occ;
                            return (
                              <button
                                key={occ}
                                type="button"
                                onClick={() => setQuizData({ ...quizData, occasion: occ })}
                                className={`py-3 px-2 text-xs rounded-full border font-medium text-center transition-all ${
                                  isSelected 
                                    ? "bg-[#745a27] text-white border-[#745a27]" 
                                    : "bg-white text-brand-800 border-[#c9a96e]/30 hover:bg-[#fdf6e8]"
                                }`}
                              >
                                {occ}
                              </button>
                            );
                          })}
                        </div>

                        {quizData.occasion === "Outra Ocasião" && (
                          <div className="pt-3 animate-slideIn">
                            <label className="text-xs font-semibold uppercase tracking-wider text-[#745a27]/80 block mb-1">Especifique a Ocasião:</label>
                            <input
                              type="text"
                              placeholder="Ex: Retorno de viagem, Novo Emprego, Superação..."
                              value={quizData.customOccasion || ""}
                              onChange={(e) => setQuizData({ ...quizData, customOccasion: e.target.value })}
                              className="w-full px-5 py-3.5 rounded-[20px] border border-[#e3dcd3] focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 text-sm bg-white text-gray-800 placeholder-gray-400 font-sans transition-all shadow-xs"
                            />
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="pt-8 border-t border-[#c9a96e]/20 flex justify-between items-center">
                  <button 
                    type="button"
                    onClick={handlePrevStep}
                    className="px-6 py-3 rounded-full font-medium text-[#745a27] hover:text-[#5a4312] transition flex items-center justify-center gap-1 text-sm cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Voltar</span>
                  </button>

                  <button 
                    id="btn-next-step-2"
                    onClick={handleNextStep}
                    disabled={
                      quizData.qualities.trim().length < 10 || 
                      quizData.unforgettableMoments.trim().length < 10 || 
                      !quizData.occasion || 
                      (quizData.occasion === "Outra Ocasião" && !quizData.customOccasion?.trim())
                    }
                    className="px-8 py-3.5 rounded-full font-medium text-sm bg-[#745a27] hover:bg-[#5a4312] disabled:opacity-50 disabled:cursor-not-allowed text-white flex items-center justify-center gap-1 transition cursor-pointer"
                  >
                    <span>Continuar</span>
                    <ChevronRight className="w-4 h-4 text-[#e8c97a]" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: GENRE & VOICE */}
            {quizStep === 3 && (
              <div className="space-y-6 animate-slideIn">
                <div className="space-y-1 text-center sm:text-left">
                  <h2 className="font-serif text-2xl font-bold text-[#1a1208] tracking-tight">Estilo Musical</h2>
                </div>

                <div className="space-y-6 pt-2">
                  {/* Genre radiocards in a grid */}
                  <div className="space-y-3">
                    <label className="text-sm font-semibold text-gray-800 block">Gênero preferido <span className="text-red-500">*</span></label>
                    <div className="grid grid-cols-3 gap-2 sm:gap-4">
                      {GENRES.map((g) => {
                        const isSelected = quizData.genre === g.name;
                        return (
                          <div
                            key={g.id}
                            onClick={() => {
                              setQuizData({ ...quizData, genre: g.name });
                            }}
                            className={`relative flex flex-col justify-center items-center text-center p-2 sm:p-4 rounded-[1.25rem] border transition-all duration-300 cursor-pointer select-none group aspect-square min-h-[92px] sm:min-h-[115px] ${
                              isSelected 
                                ? "bg-[#fffcf6] border-[#745a27] ring-1 ring-[#745a27]/20 shadow-md scale-[1.02]" 
                                : "bg-white border-[#e3dcd3] hover:border-[#c9a96e] hover:shadow-xs"
                            }`}
                          >
                            {/* Checkmark top right */}
                            {isSelected && (
                              <div className="absolute top-1.5 right-1.5 sm:top-2.5 sm:right-2.5 flex items-center justify-center w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-[#745a27] text-white shadow-xs">
                                <Check className="w-2 h-2 sm:w-3 sm:h-3 stroke-[3]" />
                              </div>
                            )}

                            {/* Large visual emoji */}
                            <span className="text-xl sm:text-2xl mb-1 filter drop-shadow-sm transition-transform group-hover:scale-110 duration-200 block">
                              {g.emoji}
                            </span>

                            {/* Human, bold literal labels */}
                            <span className="font-sans font-semibold text-[10px] sm:text-xs text-gray-800 leading-tight block text-center max-w-full">
                              {g.name}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    <AnimatePresence>
                      {quizData.genre === "Outro Estilo" && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                          className="pt-3 overflow-hidden space-y-2"
                        >
                          <label className="text-sm font-semibold text-gray-800 block">Especifique o estilo musical desejado: <span className="text-red-500">*</span></label>
                          <input
                            type="text"
                            required
                            placeholder="Ex: Rock Melódico, Heavy Metal, Reggae, Forró Pé de Serra..."
                            value={quizData.customGenre || ""}
                            onChange={(e) => setQuizData({ ...quizData, customGenre: e.target.value })}
                            className="w-full px-5 py-3.5 rounded-[20px] border border-[#e3dcd3] focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 text-sm bg-white text-gray-800 placeholder-gray-400 font-sans transition-all shadow-xs"
                          />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Vocalist voice style choices (animated in smoothly when genre is selected) */}
                  <AnimatePresence>
                    {quizData.genre && (
                      <motion.div
                        key="voice-selection-section"
                        initial={{ opacity: 0, height: 0, y: 15 }}
                        animate={{ opacity: 1, height: "auto", y: 0 }}
                        exit={{ opacity: 0, height: 0, y: 15 }}
                        transition={{ type: "spring", stiffness: 300, damping: 25 }}
                        className="space-y-3 pt-3 overflow-hidden"
                      >
                        <div>
                          <label className="text-sm font-semibold text-gray-800 block">Escolha a voz <span className="text-red-500">*</span></label>
                          <p className="text-xs text-[#745a27] font-light mt-0.5">Quem você quer que cante a música?</p>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {VOICES.map((v) => {
                            const isSelected = quizData.voiceType === v.name;
                            return (
                              <button
                                key={v.id}
                                type="button"
                                onClick={() => setQuizData({ ...quizData, voiceType: v.name })}
                                className={`p-4 rounded-xl border text-left flex flex-col justify-between transition duration-300 relative ${
                                  isSelected 
                                    ? "bg-[#fffcf6] border-[#745a27] ring-1 ring-[#745a27]/20 shadow-sm" 
                                    : "bg-white border-[#e3dcd3]/80 hover:bg-[#fffbf6] hover:border-[#c9a96e]"
                                }`}
                              >
                                {isSelected && (
                                  <div className="absolute top-3 right-3 flex items-center justify-center w-5 h-5 rounded-full bg-[#745a27] text-white">
                                    <Check className="w-3 h-3 stroke-[3]" />
                                  </div>
                                )}
                                <div className="text-left pr-6">
                                  <span className="font-serif font-semibold text-xs.5 text-[#1a1208] block">{v.name}</span>
                                  <p className="text-[10px] text-brand-800/70 mt-1.5 font-light leading-relaxed">{v.description}</p>
                                </div>
                                
                                {v.id === "dueto" && (
                                  <span className="mt-3 text-[9px] font-mono tracking-wider font-bold text-[#745a27] bg-[#fdf6e8] px-1.5 py-0.5 rounded border border-[#c9a96e]/50 uppercase block text-center">PREMIUM ✨</span>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="pt-8 border-t border-[#c9a96e]/20 flex justify-between items-center">
                  <button 
                    type="button"
                    onClick={handlePrevStep}
                    className="px-6 py-3 rounded-full font-medium text-[#745a27] hover:text-[#5a4312] transition flex items-center justify-center gap-1 text-sm cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Voltar</span>
                  </button>

                  <button 
                    id="btn-next-step-3"
                    onClick={handleNextStep}
                    disabled={!quizData.genre || (quizData.genre === "Outro Estilo" && !quizData.customGenre?.trim())}
                    className="px-8 py-3.5 rounded-full font-medium text-sm bg-[#745a27] hover:bg-[#5a4312] disabled:opacity-50 disabled:cursor-not-allowed text-white flex items-center justify-center gap-1 transition cursor-pointer"
                  >
                    <span>Continuar</span>
                    <ChevronRight className="w-4 h-4 text-[#e8c97a]" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4: CHOOSE PLAN */}
            {quizStep === 4 && (
              <div className="space-y-6 animate-slideIn">
                {/* Reference-like Breadcrumb and Voltar */}
                <div className="flex justify-between items-center text-xs text-brand-800/60 pb-3 border-b border-[#c9a96e]/10">
                  <button 
                    type="button"
                    onClick={handlePrevStep}
                    className="flex items-center gap-1 hover:text-[#745a27] transition-all cursor-pointer font-medium"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Voltar</span>
                  </button>
                  <div className="flex gap-3 sm:gap-4 font-light text-[10px] sm:text-xs">
                    <span className="opacity-60">Sua história</span>
                    <span className="text-[#745a27] font-semibold border-b border-[#745a27] pb-0.5">Escolha o plano</span>
                    <span className="opacity-60">Pagamento</span>
                  </div>
                </div>

                <div className="text-center py-2">
                  <h2 className="font-serif text-3xl font-bold text-[#1a1208] tracking-tight">Escolha seu plano</h2>
                  <p className="text-sm text-brand-800/70 font-light mt-1">Os dois planos incluem uma música única e personalizada</p>
                </div>

                <div className="w-full max-w-[560px] mx-auto flex flex-col gap-4 relative">
                  
                  {/* BÁSICO CARD */}
                  {(() => {
                    const plan = PLANS.find(p => p.id === "basico") || PLANS[0];
                    const isSelected = quizData.planId === "basico";
                    return (
                      <div 
                        onClick={() => setQuizData({ ...quizData, planId: "basico" })}
                        className={`plan-card cursor-pointer bg-white rounded-2xl p-5 flex flex-col relative transition-all duration-300 border-2 text-left ${
                          isSelected 
                            ? "border-[#745a27] ring-1 ring-[#745a27]/20 shadow-md scale-[1.01]" 
                            : "border-[#e3dcd3]/80 hover:border-[#c9a96e] hover:bg-[#fffbf6]/30"
                        }`}
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex gap-4">
                            <div className="w-12 h-12 rounded-full bg-[#fdebda]/50 flex items-center justify-center shrink-0 text-[#745a27]">
                              <Clock className="w-6 h-6 stroke-[2]" />
                            </div>
                            <div className="text-left">
                              <h3 className="font-bold text-[#1a1208] text-base">Básico</h3>
                              <p className="text-xs text-[#745a27] font-semibold">Entrega em até 24h</p>
                            </div>
                          </div>
                          
                          <div className="text-right flex flex-col items-end">
                            <span className="font-serif text-2xl font-bold text-[#1a1208] leading-none">R$29,90</span>
                            <div className="mt-2 text-[#745a27] w-6 h-6 flex items-center justify-center">
                              {isSelected ? (
                                <div className="w-6 h-6 rounded-full bg-[#745a27] text-white flex items-center justify-center">
                                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                                </div>
                              ) : (
                                <div className="w-6 h-6 rounded-full border-2 border-gray-300 bg-white"></div>
                              )}
                            </div>
                          </div>
                        </div>

                        <p className="text-sm text-brand-800/85 mb-4 text-left">Ideal para quem pode esperar um pouco mais</p>
                        <hr className="border-t border-[#f1e0ce] mb-4" />
                        
                        <ul className="flex flex-col gap-2 text-left">
                          <li className="flex items-center gap-3 text-xs sm:text-sm text-brand-800/80">
                            <Check className="text-[#c9a96e] w-4 h-4 shrink-0 stroke-[2.5]" />
                            <span>1 versão da música</span>
                          </li>
                          <li className="flex items-center gap-3 text-xs sm:text-sm text-brand-800/80">
                            <Check className="text-[#c9a96e] w-4 h-4 shrink-0 stroke-[2.5]" />
                            <span>Download em MP3</span>
                          </li>
                          <li className="flex items-center gap-3 text-xs sm:text-sm text-brand-800/80">
                            <Check className="text-[#c9a96e] w-4 h-4 shrink-0 stroke-[2.5]" />
                            <span>Entrega em até 24h</span>
                          </li>
                        </ul>
                      </div>
                    );
                  })()}

                  {/* Mais Popular Badge overlapping or centered between cards */}
                  <div className="flex justify-center -my-2 z-10">
                    <span className="bg-[#745a27] text-white px-4 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shadow-sm">
                      Mais Popular
                    </span>
                  </div>

                  {/* FLASH CARD */}
                  {(() => {
                    const plan = PLANS.find(p => p.id === "flash") || PLANS[1];
                    const isSelected = quizData.planId === "flash";
                    return (
                      <div 
                        onClick={() => setQuizData({ ...quizData, planId: "flash" })}
                        className={`plan-card cursor-pointer bg-white rounded-2xl p-5 flex flex-col relative transition-all duration-300 border-2 text-left ${
                          isSelected 
                            ? "border-[#745a27] ring-1 ring-[#745a27]/20 shadow-md scale-[1.01]" 
                            : "border-[#e3dcd3]/80 hover:border-[#c9a96e] hover:bg-[#fffbf6]/30"
                        }`}
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex gap-4">
                            <div className="w-12 h-12 rounded-full bg-[#fedb9b]/50 flex items-center justify-center shrink-0 text-[#745a27]">
                              <Sparkles className="w-6 h-6 stroke-[2]" />
                            </div>
                            <div className="text-left">
                              <h3 className="font-bold text-[#1a1208] text-base font-sans">Flash</h3>
                              <p className="text-xs text-[#745a27] font-semibold">Entrega em até 1h</p>
                            </div>
                          </div>
                          
                          <div className="text-right flex flex-col items-end">
                            <span className="font-serif text-2xl font-bold text-[#1a1208] leading-none">R$49,90</span>
                            <div className="mt-2 text-[#745a27] w-6 h-6 flex items-center justify-center font-bold">
                              {isSelected ? (
                                <div className="w-6 h-6 rounded-full bg-[#745a27] text-white flex items-center justify-center">
                                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                                </div>
                              ) : (
                                <div className="w-6 h-6 rounded-full border-2 border-gray-300 bg-white"></div>
                              )}
                            </div>
                          </div>
                        </div>

                        <p className="text-sm text-brand-800/85 mb-4 text-left font-sans font-normal opacity-90">Prioridade máxima + suporte por WhatsApp</p>
                        <hr className="border-t border-[#f1e0ce] mb-4" />
                        
                        <ul className="flex flex-col gap-2 text-left">
                          <li className="flex items-center gap-3 text-xs sm:text-sm text-brand-800/80">
                            <Check className="text-[#c9a96e] w-4 h-4 shrink-0 stroke-[2.5]" />
                            <span>Tudo do plano básico</span>
                          </li>
                          <li className="flex items-center gap-3 text-xs sm:text-sm text-brand-800/80">
                            <Check className="text-[#c9a96e] w-4 h-4 shrink-0 stroke-[2.5]" />
                            <span>Prioridade de entrega em até 1h</span>
                          </li>
                          <li className="flex items-center gap-3 text-xs sm:text-sm text-brand-800/80">
                            <Check className="text-[#c9a96e] w-4 h-4 shrink-0 stroke-[2.5]" />
                            <span>2 versões da música incluídas</span>
                          </li>
                          <li className="flex items-center gap-3 text-xs sm:text-sm text-brand-800/80">
                            <Check className="text-[#c9a96e] w-4 h-4 shrink-0 stroke-[2.5]" />
                            <span>Suporte via WhatsApp</span>
                          </li>
                        </ul>
                      </div>
                    );
                  })()}

                  {/* Guarantee Section */}
                  <div className="mt-2 bg-[#f0faf4] border border-[#d1e7dd] rounded-2xl p-4 flex gap-4 items-start text-left">
                    <ShieldCheck className="w-6 h-6 text-[#198754] shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-[#146c43] text-sm">Garantia de 7 dias</h4>
                      <p className="text-xs text-[#198754] leading-relaxed">Não ficou satisfeito? Reembolso total, sem perguntas.</p>
                    </div>
                  </div>

                  {/* Action Button */}
                  <button 
                    type="button"
                    onClick={handleNextStep}
                    className="w-full bg-[#745a27] hover:bg-[#5a4312] text-white py-4 rounded-xl font-bold mt-2 hover:opacity-95 transition-all text-sm flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer shadow-sm hover:shadow-md"
                  >
                    <span>Continuar com {quizData.planId === "basico" ? "Básico" : "Flash"} — R$ {quizData.planId === "basico" ? "29,90" : "49,90"}</span>
                    <ChevronRight className="w-4 h-4 text-[#e8c97a]" />
                  </button>

                </div>
              </div>
            )}

            {/* STEP 5: CONTACT INFORMATION & FINALIZE */}
            {quizStep === 5 && (
              <form onSubmit={handleFormFinish} className="space-y-6 animate-slideIn">
                {/* Reference-like Top Navigation Breadcrumb */}
                <div className="flex justify-between items-center w-full pb-3 border-b border-[#c9a96e]/10">
                  <button 
                    type="button" 
                    onClick={handlePrevStep}
                    className="flex items-center gap-1 text-[#745a27] font-semibold hover:opacity-70 transition-opacity cursor-pointer text-xs"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Voltar</span>
                  </button>
                  <div className="flex items-center gap-1 text-[#2e7d32] text-xs font-semibold">
                    <Lock className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Pagamento seguro</span>
                  </div>
                </div>

                {/* Header Section */}
                <section className="text-center sm:text-left space-y-1.5 py-1">
                  <h1 className="font-serif text-3xl font-bold text-[#1a1208] tracking-tight leading-tight">
                    Você está quase lá!
                  </h1>
                  <p className="text-sm font-light text-brand-800/80 leading-relaxed">
                    A um passo de presentear <span className="text-[#745a27] font-medium italic">{quizData.targetName || "seu amor"}</span> com uma música que vai durar para sempre.
                  </p>
                </section>

                {/* Status Badges */}
                <div className="flex flex-wrap gap-2.5 justify-center sm:justify-start">
                  <div className="flex items-center gap-1.5 bg-white px-3.5 py-1.5 rounded-full border border-[#c9a96e]/20 shadow-xs">
                    <Clock className="w-3.5 h-3.5 text-[#c9a96e]" />
                    <span className="text-xs text-[#1a1208] font-medium">Entrega em {quizData.planId === "basico" ? "24h" : "1h"}</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-[#fedb9b]/25 px-3.5 py-1.5 rounded-full border border-[#c9a96e]/35 shadow-xs">
                    <Star className="w-3.5 h-3.5 text-[#745a27] fill-[#745a27]/20" />
                    <span className="text-xs text-[#745a27] font-bold">Plano {quizData.planId === "basico" ? "Básico" : "Premium"}</span>
                  </div>
                </div>

                {/* Card 1: Contact Info (Simplified, formatted exactly like reference) */}
                <div className="bg-white rounded-xl p-5 sm:p-6 border border-[#c9a96e]/30 space-y-4 shadow-xs text-left">
                  <div className="space-y-1">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-800/70">Seu Nome</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Digite seu nome completo" 
                      value={quizData.clientName}
                      onChange={(e) => setQuizData({ ...quizData, clientName: e.target.value })}
                      className="w-full bg-white px-4 py-3 rounded-lg border border-[#c9a96e]/30 focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 font-sans text-sm text-[#1a1208] transition-all"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-brand-800/70">Seu WhatsApp (com DDD)</label>
                    <input 
                      type="tel" 
                      required
                      placeholder="Ex: (11) 98888-7777" 
                      value={quizData.clientWhatsapp}
                      onChange={(e) => setQuizData({ ...quizData, clientWhatsapp: e.target.value })}
                      className="w-full bg-white px-4 py-3 rounded-lg border border-[#c9a96e]/30 focus:outline-none focus:border-[#745a27] focus:ring-1 focus:ring-[#745a27]/20 font-sans text-sm text-[#1a1208] transition-all"
                    />
                  </div>
                </div>

                {/* Primary CTA Area */}
                <div className="space-y-2 text-center md:text-left">
                  <button 
                    type="submit"
                    className="w-full bg-[#c9a96e] hover:bg-[#745a27] text-white font-bold py-4 px-3 sm:px-6 rounded-xl transition duration-300 transform active:scale-[0.98] shadow-lg shadow-[#c9a96e]/20 flex items-center justify-center gap-2 cursor-pointer text-xs min-[400px]:text-sm sm:text-base leading-none"
                  >
                    <span className="text-center font-bold">Continuar para o Pagamento — R$ {total.toFixed(2).replace(".", ",")}</span>
                    <ArrowRight className="w-4 h-4 text-white shrink-0" />
                  </button>
                  <div className="flex items-center justify-center gap-1 text-brand-800/60 text-xs">
                    <Lock className="w-3.5 h-3.5 text-brand-800/40" />
                    <span>Pagamento 100% seguro e criptografado</span>
                  </div>
                </div>

                {/* Card 2: Order Review */}
                <div className="bg-white rounded-xl p-5 sm:p-6 border border-[#c9a96e]/30 space-y-4 text-left shadow-xs">
                  <h3 className="font-serif text-xl font-medium text-[#745a27] border-b border-[#c9a96e]/15 pb-2">Revisão do Pedido</h3>
                  <div className="space-y-3">
                    
                    <button 
                      type="button"
                      onClick={() => setQuizStep(4)}
                      className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-[#fdf6e8]/40 border border-transparent hover:border-[#c9a96e]/25 transition-all group text-left cursor-pointer"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-[#fff8f4] border border-[#c9a96e]/20 flex items-center justify-center text-[#745a27] shrink-0">
                          <Star className="w-5 h-5 fill-[#745a27]/10" />
                        </div>
                        <div>
                          <p className="text-xs text-brand-800/60 font-medium">Plano Selecionado</p>
                          <p className="text-sm text-[#1a1208] font-bold">
                            {quizData.planId === "basico" ? "Premium - R$ 29,90" : "Flash - R$ 49,90"}
                          </p>
                        </div>
                      </div>
                      <span className="text-[#c9a96e] text-xs font-semibold opacity-60 group-hover:opacity-100 transition-opacity">Editar</span>
                    </button>

                    <button 
                      type="button"
                      onClick={() => setQuizStep(3)}
                      className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-[#fdf6e8]/40 border border-transparent hover:border-[#c9a96e]/25 transition-all group text-left cursor-pointer"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-[#fff8f4] border border-[#c9a96e]/20 flex items-center justify-center text-[#745a27] shrink-0">
                          <Music className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-xs text-brand-800/60 font-medium">Estilo Musical & Voz</p>
                          <p className="text-sm text-[#1a1208] font-bold">
                            {quizData.genre === "Outro Estilo" ? (quizData.customGenre || "Estilo Próprio") : quizData.genre} ({quizData.voiceType})
                          </p>
                        </div>
                      </div>
                      <span className="text-[#c9a96e] text-xs font-semibold opacity-60 group-hover:opacity-100 transition-opacity">Editar</span>
                    </button>

                    <button 
                      type="button"
                      onClick={() => setQuizStep(2)}
                      className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-[#fdf6e8]/40 border border-transparent hover:border-[#c9a96e]/25 transition-all group text-left cursor-pointer"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-[#fff8f4] border border-[#c9a96e]/20 flex items-center justify-center text-[#745a27] shrink-0">
                          <Heart className="w-5 h-5 text-rose-500 fill-rose-500/10" />
                        </div>
                        <div>
                          <p className="text-xs text-brand-800/60 font-medium">Respostas do Questionário</p>
                          <p className="text-sm text-[#1a1208] font-semibold text-left">Editar memórias e história</p>
                        </div>
                      </div>
                      <span className="text-[#c9a96e] text-xs font-semibold opacity-60 group-hover:opacity-100 transition-opacity">Editar</span>
                    </button>

                  </div>
                </div>

                {/* Card 3: Guarantees */}
                <div className="bg-[#f0faf4] rounded-xl p-5 border border-emerald-500/20 text-left space-y-2">
                  <div className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-white flex items-center justify-center shrink-0 border border-emerald-300 mt-0.5 text-emerald-700">
                      <Check className="w-3.5 h-3.5 stroke-[3.5]" />
                    </div>
                    <div className="space-y-1">
                      <p className="font-sans text-sm font-bold text-emerald-800">Sua satisfação é nossa prioridade</p>
                      <ul className="space-y-1.5 text-xs text-emerald-900/80 font-light">
                        <li className="flex items-center gap-1.5">
                          <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full shrink-0"></div>
                          <span>Satisfação 100% garantida ou ajustes ilimitados</span>
                        </li>
                        <li className="flex items-center gap-1.5">
                          <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full shrink-0"></div>
                          <span>7 dias de garantia incondicional</span>
                        </li>
                        <li className="flex items-center gap-1.5">
                          <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full shrink-0"></div>
                          <span>Compra livre de riscos</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Trust Signals */}
                <div className="bg-white rounded-xl p-5 border border-[#c9a96e]/30 space-y-3.5 text-left shadow-xs">
                  <div className="flex items-center gap-2.5 text-xs text-brand-800/85">
                    <ShieldCheck className="w-4.5 h-4.5 text-[#c9a96e] shrink-0" />
                    <span>+1.000 clientes emocionados</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-brand-800/85 border-t border-[#c9a96e]/10 pt-3">
                    <Lock className="w-4.5 h-4.5 text-[#c9a96e] shrink-0" />
                    <span>Ambiente de pagamento seguro SSL</span>
                  </div>
                  <div className="flex items-center gap-2.5 text-xs text-brand-800/85 border-t border-[#c9a96e]/10 pt-3">
                    <Sparkles className="w-4.5 h-4.5 text-[#c9a96e] shrink-0" />
                    <span>Compositores profissionais dedicados</span>
                  </div>
                </div>

                {/* Secondary CTA */}
                <div className="py-4 space-y-4">
                  <button 
                    type="submit"
                    className="w-full bg-[#c9a96e] hover:bg-[#745a27] text-white font-bold py-4 px-3 sm:px-6 rounded-xl transition duration-300 transform active:scale-[0.98] shadow-lg shadow-[#c9a96e]/20 flex items-center justify-center gap-2 cursor-pointer text-xs min-[400px]:text-sm sm:text-base leading-none"
                  >
                    <span className="text-center font-bold">Garantir minha música agora</span>
                    <ArrowRight className="w-4 h-4 text-white shrink-0" />
                  </button>
                  
                  <div className="flex justify-center gap-6 opacity-40 grayscale py-2">
                    <img alt="PayPal" className="h-4" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBJhbHMyOMtTtgCXGJ0RoqnVZv0-yr11641NKCmiqiuw3zzyZp2QQP8MprYHx285gUrQ3eg5uhEfvC_F1Q7ETBiaPgGyeYmSmO4Cf9if7-yD_73nxF1oru227uCJZFCMSyA1fCanW_8oeh1Z7688BDD1X__3jG3Anq_7SgPAydVhKnnvtmR84mIslU3Q9Uyl809eJyVXc722GT3u3HscELaFpgPItXUEOmipFkPolyLhQhJttnBtR-4tjmS9A2kImssik1G1M6R3-K4"/>
                    <img alt="Visa" className="h-4" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDJFlpvOlq3JriSz1WRM87nUZBT5zLRzESKFuXFyFk35GaR9_pXs8_751h9hwoMzhphJ2cMoZHpg-7Dp8bi4rnzdS0MaCC5jKlsHTtKH2FQ0uVSIGazM9kqGi_SkmAhwAqPmp-YouT9OE9y1zR24AOtjFMlWSZtSP8u_yGmEV7WBG-_gagiQwkae-SmB1F2zt6KU0mXKKXWgiqxbMjBMVss-cUQChiRErehUan28gBLGDuDCjHz-cHd5U0VFAyf-mwpDUuC4IyEmyHp"/>
                    <img alt="Mastercard" className="h-4" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBTLuUbTpm37MgygJEzB2pdKXUnK8JZO8hW4Lwj5BLwjqu93aXajC51cvO9tsJgIgIhNt5m2MoGLjqcqvSojPYwbkiHY8d4yeRLEGaELRy4LO6eRiMAxpFpg6iHv5K8fAQCSL3FUxCM0ewX7SQtFrPTx5YmlvT8f58IRCBAUWPfCTGqbDXXtg07M3e3ua4POSBLUSLL_-QX8RdDS5lBca8lWu4wuzP78ZoFkE6vTp2igex_Vrf7BgVLiKkEZ_1Y8247Fs29jEyEZTVd"/>
                    <img alt="Pix" className="h-4" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBwZpRqboxitWiyNls_zdNIlBcspWViNADS0hCQEEaiAxlSQfYWMvqOwQB5QSQ8PHCEB1Nl1cWq0xpuolRkC7gpAuEGOGXmfdz90CD4ZItK-WJctHBvzWVNHPm1cKkJI8hTNkqLB-o9P4QUnaNdCPa_haABN80xcyw-QIkD0u3VRMsaZ1VdQV0JWtfzz0XKRmZsbDesocPZ3dLHzXHA9s4XbtgSaZP0THPjW9A0RGw85w00_5GyPt9IW7s7SYyg7XkTpp0Sfg4cjI0I"/>
                  </div>
                </div>
              </form>
            )}

          </div>
        </main>
      )}

      {/* CHECKOUT & SIMULATED PAYMENT VIEW */}
      {view === "checkout" && (
        <main className="max-w-2xl mx-auto px-6 py-12 animate-fadeIn">
          <div className="bg-white rounded-lg p-6 sm:p-10 border border-[#c9a96e]/30 text-center space-y-8 romantic-glow">
            
            <div className="space-y-2">
              <span className="text-[10px] font-mono tracking-widest bg-[#fdf6e8] rounded border border-[#c9a96e]/40 text-[#745a27] font-bold uppercase px-3 py-1 inline-block">Processamento de Faturamento</span>
              <h2 className="font-serif text-3xl font-medium text-[#1a1208] tracking-tight">Efetuar Pagamento</h2>
              <p className="text-xs text-[#745a27] font-light max-w-md mx-auto">Para compor e liberar seu resultado musical de estúdio, proceda com o pagamento assegurado abaixo.</p>
            </div>

            {/* Price badge card */}
            <div className="p-4 bg-[#fdf6e8] rounded-lg border border-[#c9a96e]/40 inline-block px-12">
              <span className="text-xs text-[#745a27] block">Total a Pagar</span>
              <span className="text-3xl font-semibold font-serif text-[#1a1208]">R$ {total.toFixed(2).replace(".", ",")}</span>
            </div>

            {/* TAB SELECTOR METHOD */}
            <div className="flex border-b border-[#c9a96e]/20 max-w-sm mx-auto">
              <button
                onClick={() => setActiveTab("pix")}
                className={`flex-1 pb-3 text-sm font-semibold flex items-center justify-center gap-1.5 transition ${
                  activeTab === "pix" ? "border-b-2 border-[#745a27] text-[#745a27]" : "text-[#c9a96e] hover:text-[#745a27]"
                }`}
              >
                <span>♩ Pix Copia e Cola</span>
              </button>
              <button
                onClick={() => setActiveTab("card")}
                className={`flex-1 pb-3 text-sm font-semibold flex items-center justify-center gap-1.5 transition ${
                  activeTab === "card" ? "border-b-2 border-[#745a27] text-[#745a27]" : "text-[#c9a96e] hover:text-[#745a27]"
                }`}
              >
                <span>💳 Cartão de Crédito</span>
              </button>
            </div>

            {/* TAB 1: PIX */}
            {activeTab === "pix" && (
              <div className="space-y-6 pt-2 animate-slideIn">
                <div className="flex justify-center">
                  {/* Generated QR Mockup */}
                  <div className="w-44 h-44 bg-white rounded-lg p-3 border border-[#c9a96e]/40 flex flex-col items-center justify-center relative overflow-hidden select-none">
                    <img
                      referrerPolicy="no-referrer"
                      src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=0fe9881a-2bea-4fa6-9a73-24c5ba7bca1c"
                      alt="Pix QR Code"
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>

                <div className="space-y-2.5 max-w-md mx-auto">
                  <p className="text-xs text-[#745a27] font-light">Escaneie o QR Code acima pelo app do seu banco ou copie as coordenadas abaixo:</p>
                  
                  <div className="flex rounded-lg border border-[#c9a96e]/40 overflow-hidden bg-[#fdf6e8] shadow-xs">
                    <input 
                      type="text" 
                      readOnly 
                      value="0fe9881a-2bea-4fa6-9a73-24c5ba7bca1c@melodiasdeamor.com.br"
                      className="flex-1 px-4 py-2.5 text-[11px] font-mono text-slate-500 bg-transparent border-none focus:outline-none focus:ring-0 truncate"
                    />
                    <button
                      type="button"
                      onClick={handleCopyPix}
                      className="bg-[#745a27] hover:bg-[#5a4312] text-white font-semibold text-xs px-4 flex items-center justify-center gap-1.5 transition shrink-0 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5 text-[#e8c97a]" />
                      <span>{clipboardCopied ? "Copiado!" : "Copiar"}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: CREDIT CARD */}
            {activeTab === "card" && (
              <div className="space-y-4 text-left max-w-md mx-auto animate-slideIn">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-[#745a27]">Número do Cartão de Crédito</label>
                  <input 
                    type="text" 
                    placeholder="4000 1234 5678 9010" 
                    className="w-full px-4 py-3 rounded-lg border border-[#c9a96e]/30 text-xs focus:outline-none focus:border-[#745a27] bg-transparent"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#745a27]">Validade</label>
                    <input 
                      type="text" 
                      placeholder="MM/AA" 
                      className="w-full px-4 py-3 rounded-lg border border-[#c9a96e]/30 text-xs focus:outline-none focus:border-[#745a27] bg-transparent"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-[#745a27]">CVC</label>
                    <input 
                      type="password" 
                      maxLength={4}
                      placeholder="123" 
                      className="w-full px-4 py-3 rounded-lg border border-[#c9a96e]/30 text-xs focus:outline-none focus:border-[#745a27] bg-transparent"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-[#745a27]">Nome impresso no Cartão</label>
                  <input 
                    type="text" 
                    placeholder="JOAO D SILVA" 
                    className="w-full px-4 py-3 rounded-lg border border-[#c9a96e]/30 text-xs focus:outline-none focus:border-[#745a27] bg-transparent"
                  />
                </div>
              </div>
            )}

            {/* SIMULATED WEBHOOK TRIGGER BUTTON */}
            <div className="pt-6 border-t border-[#c9a96e]/15 max-w-md mx-auto space-y-4">
              <button
                onClick={handleSimulatedPayment}
                disabled={simulatedPaying}
                className="w-full py-4 rounded-full font-semibold bg-emerald-700 hover:bg-emerald-800 text-white transition duration-300 transform hover:-translate-y-0.5 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {simulatedPaying ? (
                  <>
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Confirmando Pagamento...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-5 h-5 stroke-[3] text-white" />
                    <span>Confirmar Pagamento (Simulação)</span>
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-4 text-[#745a27]/60 text-[10px] font-medium uppercase tracking-widest font-sans">
                <span className="flex items-center gap-1">🔒 Conexão Criptografada</span>
                <span>•</span>
                <span className="flex items-center gap-1">🛡️ Certificado SSL Ativo</span>
              </div>
            </div>

          </div>
        </main>
      )}

      {/* CREATION LOADING VIEW */}
      {view === "loading" && (
        <main className="flex-grow flex items-center justify-center px-4 sm:px-6 pt-16 pb-20 animate-fadeIn">
          <div className="w-full max-w-[560px] bg-white border border-[#c9a96e]/30 p-8 sm:p-12 text-center rounded-2xl shadow-sm space-y-10 my-4 sm:my-8 relative overflow-hidden romantic-glow animate-fadeIn">
            {/* Top gold accent line */}
            <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-[#e8c97a] via-[#c9a96e] to-[#745a27]"></div>

            {/* Header Titles */}
            <div className="space-y-3 pt-2">
              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#1a1208] leading-tight">
                Sua música está sendo criada ❤️
              </h1>
              <p className="font-sans text-xs sm:text-sm text-brand-800/80 font-light leading-relaxed">
                Estamos transformando sua história em uma música única. Isso pode levar alguns instantes.
              </p>
            </div>

            {/* Central Animation Container */}
            <div className="relative w-36 h-36 sm:w-40 sm:h-40 mx-auto flex items-center justify-center">
              {/* Decorative pulse rings */}
              <div className="absolute inset-0 rounded-full border border-[#745a27]/20 loading-pulse"></div>
              <div className="absolute inset-4 rounded-full border border-[#745a27]/40 loading-pulse" style={{ animationDelay: "0.5s" }}></div>
              {/* Main Animated Icon */}
              <div className="note-float relative bg-[#fdf6e8]/60 p-6 rounded-full border border-[#c9a96e]/20 shadow-xs">
                <Music className="w-12 h-12 sm:w-14 sm:h-14 text-[#745a27]" />
              </div>
            </div>

            {/* Progress Bar & Status Messages Container */}
            <div className="space-y-6">
              {/* Progress Bar */}
              <div className="w-full h-1 bg-[#e8d8b0]/40 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-[#c9a96e] progress-bar-shine transition-all duration-700 ease-out" 
                  style={{ width: `${((loadingStep + 1) / loadingMessages.length) * 100}%` }}
                ></div>
              </div>

              {/* Status Messages */}
              <div className="h-6 flex items-center justify-center">
                <p className="font-sans text-xs sm:text-sm font-semibold text-[#745a27] animate-pulse">
                  {loadingMessages[loadingStep]}
                </p>
              </div>
            </div>

            {/* Trust Message */}
            <div className="border-t border-[#c9a96e]/15 pt-6">
              <p className="text-[11px] sm:text-xs font-sans italic text-brand-800/60 leading-relaxed max-w-sm mx-auto">
                Não feche esta página. Sua música aparecerá automaticamente quando estiver pronta.
              </p>
            </div>

            {/* Support Button */}
            <div className="pt-2">
              <a 
                className="inline-flex items-center gap-1.5 px-6 py-2.5 rounded-full border border-[#c9a96e] text-[#745a27] text-xs font-bold hover:bg-[#c9a96e]/5 transition-colors duration-300 shadow-xs cursor-pointer" 
                href={`https://wa.me/5511999999999?text=Olá!%20Fiz%20o%20pedido%20para%20${encodeURIComponent(quizData.targetName)}%20e%20gostaria%20de%20saber%20se%20está%20tudo%20certo.`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Phone className="w-3.5 h-3.5 text-[#745a27]" />
                <span>Suporte via WhatsApp</span>
              </a>
            </div>
          </div>
        </main>
      )}

      {/* SUCCESS / COMPLETED VIEW & LYRICS DISPLAY */}
      {view === "success" && (
        <main className="max-w-3xl mx-auto px-4 sm:px-6 py-12 animate-fadeIn space-y-8 flex flex-col items-center justify-center">
          
          {/* Central White Card representing delivery */}
          <div className="bg-white border border-[#e8d8b0] rounded-[24px] p-8 sm:p-12 w-full text-center relative overflow-hidden shadow-xs space-y-8 max-w-[560px] mx-auto animate-fadeIn">
            {/* Top gold accent line */}
            <div className="absolute top-0 left-0 w-full h-[4px] bg-[#c9a96e]"></div>

            {/* Header Group */}
            <div className="space-y-2">
              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#1a1208] leading-tight">
                Sua música está pronta ❤️
              </h1>
              <p className="font-sans text-xs sm:text-sm text-brand-800/70 font-light max-w-[340px] mx-auto">
                Criamos uma música exclusiva baseada na sua história.
              </p>
            </div>

            {/* Music Info Card */}
            <div className="w-full bg-[#fdf6e8]/40 border border-[#c9a96e]/15 rounded-2xl p-6 flex flex-col items-center space-y-3">
              <div className="w-12 h-12 bg-[#fdf6e8] border border-[#c9a96e]/20 rounded-full flex items-center justify-center shadow-xs">
                <Music className="w-6 h-6 text-[#c9a96e]" />
              </div>
              <div className="space-y-1">
                <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#745a27]" id="song-title">
                  {lyricsResult?.title || "Eterno Momento"}
                </h2>
                <p className="font-sans text-xs sm:text-sm font-semibold text-brand-800/80" id="recipient-name">
                  Para {quizData.targetName || "Ana Maria"}
                </p>
                <p className="font-sans text-[11px] text-brand-800/50 font-light" id="creation-date">
                  Criado em {new Date().toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })}
                </p>
              </div>
            </div>

            {/* Audio Player Container */}
            <div className="w-full" id="audio-player-container">
              {/* Custom Themed Player UI */}
              <div className="flex flex-col gap-4 w-full p-4 bg-[#fdf6e8]/60 border border-[#c9a96e]/10 rounded-xl">
                <div className="flex items-center gap-4">
                  <button 
                    type="button"
                    onClick={togglePrimaryPlayback}
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-[#c9a96e] hover:bg-[#745a27] text-white transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95 duration-200 shrink-0" 
                    id="player-toggle"
                  >
                    {isPlayingSong ? (
                      <Pause className="w-4 h-4 text-white fill-white" />
                    ) : (
                      <Play className="w-4 h-4 text-white fill-white ml-0.5" />
                    )}
                  </button>

                  <div className="flex-grow pt-1">
                    <input 
                      type="range" 
                      min="0" 
                      max="225" 
                      value={trackSeconds} 
                      onChange={(e) => setTrackSeconds(Number(e.target.value))}
                      className="w-full accent-[#745a27] bg-[#e8d8b0]/40 rounded-full h-1 cursor-pointer appearance-none outline-none focus:ring-0"
                      style={{
                        background: `linear-gradient(to right, #c9a96e ${((trackSeconds / 225) * 100)}%, rgba(232, 216, 176, 0.4) ${((trackSeconds / 225) * 100)}%)`
                      }}
                    />
                    <div className="flex justify-between mt-1 text-[10px] text-[#745a27] font-semibold font-sans">
                      <span>{formatSeconds(trackSeconds)}</span>
                      <span>3:45</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setTrackIsMuted(!trackIsMuted)}
                    className="text-[#c9a96e] hover:text-[#745a27] cursor-pointer shrink-0"
                  >
                    {trackIsMuted ? (
                      <VolumeX className="w-5 h-5 text-[#ba1a1a]" />
                    ) : (
                      <Volume2 className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Buttons Group */}
            <div className="w-full flex flex-col gap-3">
              <button 
                type="button"
                onClick={togglePrimaryPlayback}
                className="w-full bg-[#c9a96e] hover:bg-[#745a27] text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 hover:opacity-95 transition-all duration-300 transform active:scale-[0.98] cursor-pointer shadow-sm shadow-[#c9a96e]/10 text-sm" 
                id="btn-play"
              >
                {isPlayingSong ? (
                  <>
                    <Pause className="w-4 h-4 text-white fill-white" />
                    <span>Pausar Música</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 text-white fill-white ml-0.5" />
                    <span>Ouvir Música</span>
                  </>
                )}
              </button>

              <button 
                type="button"
                onClick={handleDownloadSong}
                className="w-full bg-white border border-[#c9a96e] text-[#c9a96e] hover:bg-[#c9a96e]/5 font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all duration-300 transform active:scale-[0.98] cursor-pointer text-sm" 
                id="btn-download"
              >
                <Download className="w-4 h-4" />
                <span>Baixar Música</span>
              </button>
            </div>

            {/* Help Link */}
            <div className="pt-2">
              <a 
                className="inline-flex items-center gap-1.5 text-xs text-brand-800/70 hover:text-[#745a27] underline decoration-[#c9a96e]/30 transition-colors"
                href={`https://wa.me/5511999999999?text=Olá!%20Fiz%20uma%20música%20para%20${encodeURIComponent(quizData.targetName)}%20e%20gostaria%20de%20ajuda.`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Preciso de ajuda</span>
              </a>
            </div>
          </div>

          {/* Emotional Footer */}
          <div className="max-w-[480px] text-center px-4 pt-2">
            <p className="font-sans text-xs sm:text-sm font-light text-brand-800/60 italic leading-relaxed">
              "Obrigado por confiar sua história a nós. Esperamos que essa música marque um momento especial na sua vida."
            </p>
          </div>

          {/* POETIC LYRICS VIEW */}
          {lyricsResult && (
            <div className="bg-[#1a1208] text-[#fdf6e8] rounded-[24px] p-6 sm:p-10 border border-[#c9a96e]/30 relative w-full space-y-8 romantic-glow mt-8">
              
              {/* Cute sound controls live for lyrics reading ambience */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#c9a96e]/20 pb-6 w-full">
                <div className="text-left space-y-1.5">
                  <span className="text-[10px] font-mono font-bold text-[#e8c97a] bg-[#745a27]/30 border border-[#c9a96e]/30 px-2.5 py-0.8 rounded uppercase tracking-wider">LETRA COMPLETA DA SUA HISTÓRIA</span>
                  <h3 className="font-serif text-2xl font-medium text-white italic">"Rascunho de Estúdio Original"</h3>
                  <p className="text-xs text-[#e8d7c6]/80 leading-relaxed font-light">Sua canção personalizada foi composta em tempo real. Você pode acompanhar a letra abaixo:</p>
                </div>
              </div>

              {/* Poetic Paper Lyrics Box */}
              <div className="bg-[#231a0f]/50 rounded-xl p-6 sm:p-8 border border-[#c9a96e]/20 font-serif text-slate-200 text-center space-y-8 select-all w-full">
                
                <div className="space-y-1">
                  <h4 className="text-2xl font-medium text-white tracking-tight italic underline decoration-[#c9a96e]/30">
                    "{lyricsResult.title}"
                  </h4>
                  <p className="font-mono text-[9px] text-[#e8c97a] uppercase tracking-widest pt-1">
                    Estilo: {quizData.genre === "Outro Estilo" ? (quizData.customGenre || "Outro Estilo") : quizData.genre} / {quizData.voiceType}
                  </p>
                </div>

                {/* Intro */}
                <div className="text-xs text-[#e8d7c6]/60 font-mono font-light italic leading-relaxed">
                  {lyricsResult.intro}
                </div>

                {/* Verso 1 */}
                <div className="space-y-1">
                  <span className="text-[9px] font-mono text-[#c9a96e] uppercase tracking-wider block mb-2">[ Verso 1 ]</span>
                  <p className="text-base sm:text-lg leading-relaxed tracking-wide whitespace-pre-line text-[#fdf6e8] font-light">
                    {lyricsResult.verso1}
                  </p>
                </div>

                {/* Verso 2 */}
                <div className="space-y-1">
                  <span className="text-[9px] font-mono text-[#c9a96e] uppercase tracking-wider block mb-2">[ Verso 2 ]</span>
                  <p className="text-base sm:text-lg leading-relaxed tracking-wide whitespace-pre-line text-[#fdf6e8] font-light">
                    {lyricsResult.verso2}
                  </p>
                </div>

                {/* Refrão */}
                <div className="space-y-1 py-5 bg-[#745a27]/10 rounded-lg border border-[#c9a96e]/20 px-4">
                  <span className="text-[9px] font-mono text-[#e8c97a] uppercase tracking-wider block mb-2">❤️ [ Refrão Principal ]</span>
                  <p className="text-lg sm:text-xl font-normal leading-relaxed tracking-wide whitespace-pre-line text-[#e8c97a] italic">
                    {lyricsResult.refrao}
                  </p>
                </div>

                {/* Ponte */}
                <div className="space-y-1">
                  <span className="text-[9px] font-mono text-[#c9a96e] uppercase tracking-wider block mb-2">[ Ponte de Transição ]</span>
                  <p className="text-base sm:text-lg leading-relaxed tracking-wide whitespace-pre-line text-[#fdf6e8] font-light">
                    {lyricsResult.ponte}
                  </p>
                </div>

                {/* Outro */}
                <div className="text-xs text-[#e8d7c6]/60 font-mono font-light italic leading-relaxed">
                  {lyricsResult.outro}
                </div>
              </div>

              {/* Action shares */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4 justify-center w-full">
                <button
                  type="button"
                  onClick={handleDownloadSong}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs py-4 px-6 rounded-full transition flex items-center justify-center gap-1.5 shadow-md border border-emerald-600/30 cursor-pointer"
                >
                  <Download className="w-4 h-4 text-emerald-350" />
                  <span>Baixar Versão para Impressão</span>
                </button>
                
                <button
                  type="button"
                  onClick={() => {
                    stopAllPreviews();
                    setPlayingGenreId(null);
                    localStorage.removeItem("melodias_de_amor_view");
                    localStorage.removeItem("melodias_de_amor_quizStep");
                    localStorage.removeItem("melodias_de_amor_quizData");
                    setQuizStep(1);
                    setQuizData({
                      targetName: "",
                      relationship: "Namorado(a)",
                      customRelationship: "",
                      qualities: "",
                      unforgettableMoments: "",
                      specialMessage: "",
                      occasion: "Aniversário",
                      customOccasion: "",
                      genre: "",
                      customGenre: "",
                      voiceType: "Voz Feminina",
                      planId: "basico",
                      couponCode: "",
                      clientName: "",
                      clientEmail: "",
                      clientWhatsapp: ""
                    });
                    setView("landing");
                  }}
                  className="bg-white/10 hover:bg-white/15 text-white font-semibold text-xs py-4 px-6 rounded-full transition border border-white/10 cursor-pointer text-center"
                >
                  Criar Outra Melodia de Amor
                </button>
              </div>

            </div>
          )}

        </main>
      )}

      {/* FOOTER - Styled in Deep Onyx as requested */}
      <footer className="bg-[#1a1208] text-[#e8d7c6]/60 py-12 px-6 border-t border-[#c9a96e]/30 text-xs text-center space-y-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#fdf6e8]/10 border border-[#c9a96e]/30 flex items-center justify-center">
              🌻
            </div>
            <span className="font-serif font-medium text-white text-lg tracking-tight">Melodias de Amor</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-[#e8d7c6]/50">
            <span>Garantia de 7 Dias</span>
            <span>•</span>
            <span>Estúdio Exclusivo</span>
            <span>•</span>
            <span>Suporte Humanizado</span>
          </div>
        </div>

        <div className="max-w-2xl mx-auto pt-6 border-t border-[#c9a96e]/15 space-y-2.5 font-light leading-relaxed">
          <p>
            Melodias de Amor - © 2026. Todos os direitos reservados.
          </p>
          <p className="text-[10px] text-[#e8d7c6]/30">
            Trabalho de criação e composição musical customizado sob regime de licenciamento e uso privado ou presentográfico. Ilustração representacional de instrumentos reais. Seus dados cadastrais estão assegurados segundo as regras de segurança geral.
          </p>
        </div>
      </footer>

    </div>
  );
}
