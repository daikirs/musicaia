import { Testimonial, FAQItem } from "./types";

export const TESTIMONIALS: Testimonial[] = [
  {
    name: "Gabriela Santos",
    relationship: "Namorada de Lucas",
    text: "Eu chorei tanto quando ouvi! Ele colocou detalhes do nosso primeiro encontro na praia que eu pensei que ele já tinha esquecido. O melhor presente de aniversário que já recebi na vida.",
    rating: 5
  },
  {
    name: "Rodrigo Almeida",
    relationship: "Marido da Thais",
    text: "Fiz para celebrar nossos 5 anos de casamento. A produção instrumental ficou impecável, parece música de rádio. Minha esposa compartilha com todo mundo no Instagram!",
    rating: 5
  },
  {
    name: "Amanda Silva",
    relationship: "Filha de Helena",
    text: "Fiz uma música de Dia das Mães contando sobre as receitas dela e as risadas aos domingos. Ela se emocionou demais e mostrou para a família inteira. Vale cada centavo!",
    rating: 5
  },
  {
    name: "Felipe Mendes",
    relationship: "Namorado de Beatriz",
    text: "A entrega do plano Flash foi super rápida, chegou em menos de 12 horas. A letra ficou super poética e o refrão gruda na cabeça de um jeito muito gostoso. Recomendo muito!",
    rating: 5
  }
];

export const FAQ_ITEMS: FAQItem[] = [
  {
    question: "Como vocês criam a letra e a melodia?",
    answer: "Nós utilizamos as informações exclusivas de momentos e qualidades que você preenche no nosso quizz. Nossa inteligência artística e compositores profissionais criam uma letra rica em rimas com alta carga emocional. Em seguida, vocalistas reais produzem e gravam a canção em estúdio com instrumental completo."
  },
  {
    question: "O valor é realmente de R$ 29,90? Sem taxas escondidas?",
    answer: "Sim! Nosso plano Básico custa apenas R$ 29,90 e te dá direito a uma música completa e personalizada com letra, melodia profissional executada e entrega direta no seu WhatsApp em formado MP3 de alta fidelidade."
  },
  {
    question: "Qual a diferença entre o Plano Básico e o Plano Flash?",
    answer: "No Plano Básico (R$ 29,90), sua música entra na fila de produção padrão e é entregue em até 24 horas. No Plano Flash (R$ 49,90), sua música ganha prioridade máxima na fila de estúdio e é enviada em até 1 hora (ideal para presentes imediatos!)."
  },
  {
    question: "Como vou receber a minha música?",
    answer: "Você receberá um link exclusivo de audição e download diretamente pelo WhatsApp e no seu e-mail de cadastro. Você poderá baixar o arquivo MP3 de alta qualidade para compartilhar nas redes sociais, enviar como mensagem de voz no WhatsApp ou reproduzir nas caixas de som."
  },
  {
    question: "Posso solicitar correções se não gostar de algum detalhe?",
    answer: "Sim! Entendemos que música mexe com sentimentos. Se houver algum erro de pronúncia ou algo que destoe muito da história enviada, você pode solicitar ajustes em até 7 dias sem custos adicionais. Nosso foco é emocionar de verdade."
  },
  {
    question: "A música é protegida por direitos autorais?",
    answer: "A música gerada é para seu uso pessoal ilimitado. Você pode tocar em eventos, casamentos, publicar nas suas redes sociais (Instagram, TikTok, YouTube) livremente sem risco de direitos autorais."
  }
];

export const RELATIONSHIPS = [
  "Namorado(a)",
  "Marido / Esposa",
  "Noivo(a)",
  "Amigo(a)",
  "Mãe / Pai",
  "Filho(a)",
  "Outro"
];

export const OCCASIONS = [
  "Aniversário",
  "Dia dos Namorados",
  "Presente",
  "Namoro",
  "Chá revelação",
  "Outra Ocasião"
];

export const GENRES = [
  {
    id: "pop",
    name: "Pop",
    emoji: "🎤",
    description: "Melodia moderna, ritmo envolvente e atual.",
    previewStyle: "acoustics"
  },
  {
    id: "sertanejo",
    name: "Sertanejo",
    emoji: "🤠",
    description: "Inspirado em duplas sertanejas, ritmo aconchegante e romântico.",
    previewStyle: "sertanejo"
  },
  {
    id: "acustico",
    name: "Acústico",
    emoji: "🎸",
    description: "Voz e violão suave, estilo íntimo e acolhedor.",
    previewStyle: "acoustics"
  },
  {
    id: "pagode",
    name: "Pagode",
    emoji: "🪘",
    description: "Batida gostosa e romântica com cavaco e pandeiro.",
    previewStyle: "pagode"
  },
  {
    id: "classico",
    name: "Clássico",
    emoji: "🎻",
    description: "Elegante e orquestral, toque sutil e emocionante.",
    previewStyle: "jazz"
  },
  {
    id: "bossa_nova",
    name: "Bossa Nova",
    emoji: "🌊",
    description: "Tom suave de jazz e violão, clima sutil e acolhedor.",
    previewStyle: "jazz"
  },
  {
    id: "rap_hip_hop",
    name: "Rap / Hip-Hop",
    emoji: "🎧",
    description: "Estilo moderno com batidas urbanas expressivas.",
    previewStyle: "pagode"
  },
  {
    id: "louvor_gospel",
    name: "Louvor / Gospel",
    emoji: "🙏",
    description: "Melodia tocante com piano e coro emocionante.",
    previewStyle: "folk"
  },
  {
    id: "outro",
    name: "Outro Estilo",
    emoji: "🎵",
    description: "Personalize do seu jeito, escolha o estilo que desejar.",
    previewStyle: "acoustics"
  }
];

export const VOICES = [
  {
    id: "feminina",
    name: "Voz Feminina",
    description: "Tom aveludado, ideal para sentimentos de carinho profundo e doces lembranças."
  },
  {
    id: "masculina",
    name: "Voz Masculina",
    description: "Voz encorpada, ideal para refrãos intensos e mensagens marcantes de amor."
  },
  {
    id: "dueto",
    name: "Dueto Romântico (+ R$ 15,00)",
    description: "Duas vozes harmonizando juntas. Transmite cumplicidade absoluta e romance total."
  }
];

export const PLANS = [
  {
    id: "basico",
    name: "Plano Básico",
    price: 29.90,
    oldPrice: 89.90,
    delivery: "Entrega em até 24h",
    features: [
      "1 versão da música",
      "Download em MP3",
      "Entrega em 5 dias"
    ]
  },
  {
    id: "flash",
    name: "Plano Flash ⚡️",
    price: 49.90,
    oldPrice: 129.90,
    delivery: "Entrega prioritária em até 1h",
    features: [
      "Tudo do Básico",
      "Prioridade entregue em 1h",
      "2 versões da música incluídas",
      "Suporte por e-mail"
    ],
    popular: true
  }
];
